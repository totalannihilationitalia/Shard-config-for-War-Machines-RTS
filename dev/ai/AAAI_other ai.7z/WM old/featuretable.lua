-- shard help feature table for WM

featureTable = {}

featureTable["aafus_dead"] = { reclaimable = true, blocking = true, unitName = "aafus", energy = 0, metal = 6441, }
featureTable["aafus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2576, }
featureTable["advmoho_dead"] = { reclaimable = true, blocking = true, unitName = "advmoho", energy = 0, metal = 1025, }
featureTable["advmoho_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 350, }
featureTable["aexxec_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 220, }
featureTable["aexxec_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 110, }
featureTable["alos_galleria_dx"] = { reclaimable = false, blocking = true, energy = 0, metal = 250, }
featureTable["alos_galleria_sx"] = { reclaimable = false, blocking = true, energy = 0, metal = 250, }
featureTable["alos_muro_ponte"] = { reclaimable = false, blocking = true, energy = 0, metal = 250, }
featureTable["alos_ponte"] = { reclaimable = false, blocking = true, energy = 0, metal = 250, }
featureTable["andaafus_dead"] = { reclaimable = true, blocking = true, unitName = "andaafus", energy = 0, metal = 6441, }
featureTable["andaafus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2576, }
featureTable["andach_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 77, }
featureTable["andach_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["andacsp_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 244, }
featureTable["andacsp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 98, }
featureTable["andaestor_dead"] = { reclaimable = true, blocking = true, unitName = "andaestor", energy = 0, metal = 514, }
featureTable["andaestor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 206, }
featureTable["andahp_dead"] = { reclaimable = true, blocking = true, unitName = "andahp", energy = 0, metal = 3206, }
featureTable["andahp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andahp_nocostr_dead"] = { reclaimable = true, blocking = true, unitName = "andahp_nocostr", energy = 0, metal = 3206, }
featureTable["andahp_nocostr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andalab_dead"] = { reclaimable = true, blocking = true, unitName = "andalab", energy = 0, metal = 3206, }
featureTable["andalab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andametex_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 1025, }
featureTable["andametex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 350, }
featureTable["andangel_dead"] = { reclaimable = true, blocking = true, unitName = "andangel", energy = 0, metal = 2720, }
featureTable["andangel_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1088, }
featureTable["andaplat_dead"] = { reclaimable = true, blocking = true, unitName = "andaplat", energy = 0, metal = 1953, }
featureTable["andarad_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 35, }
featureTable["andarad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["andartic_andartic_dead"] = { reclaimable = true, blocking = true, unitName = "andartic", energy = 0, metal = 244, }
featureTable["andartic_andartic_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 101, }
featureTable["andbrskr_andbrskr_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 128, }
featureTable["andbrskr_andbrskr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 77, }
featureTable["andch_dead"] = { reclaimable = true, blocking = true, unitName = "andch", energy = 0, metal = 77, }
featureTable["andch_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["andcom_dead"] = { reclaimable = true, blocking = true, unitName = "andcom", energy = 0, metal = 2500, }
featureTable["andcom_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["andcsp_dead"] = { reclaimable = true, blocking = true, unitName = "andcsp", energy = 0, metal = 244, }
featureTable["andcsp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 98, }
featureTable["anddauber_coredauber_dead"] = { reclaimable = true, blocking = true, unitName = "anddauber", energy = 0, metal = 148, }
featureTable["anddfens_cordfens_dead"] = { reclaimable = true, blocking = true, unitName = "anddfens", energy = 0, metal = 1510, }
featureTable["anddfens_cordfens_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 650, }
featureTable["andestor_dead"] = { reclaimable = true, blocking = true, unitName = "andestor", energy = 0, metal = 108, }
featureTable["andestor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 43, }
featureTable["andfury_dead"] = { reclaimable = true, blocking = true, unitName = "andfury", energy = 0, metal = 214, }
featureTable["andfury_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 198, }
featureTable["andfus_dead"] = { reclaimable = true, blocking = true, unitName = "andfus", energy = 0, metal = 2603, }
featureTable["andfus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1041, }
featureTable["andgant_dead"] = { reclaimable = true, blocking = true, unitName = "andgant", energy = 0, metal = 3206, }
featureTable["andgant_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andgaso_dead"] = { reclaimable = true, blocking = true, unitName = "andgaso", energy = 0, metal = 77, }
featureTable["andgaso_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["andhartic_andhartic_dead"] = { reclaimable = true, blocking = true, unitName = "andhartic", energy = 0, metal = 244, }
featureTable["andhartic_andhartic_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 101, }
featureTable["andhp_dead"] = { reclaimable = true, blocking = true, unitName = "andhp", energy = 0, metal = 3206, }
featureTable["andhp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andhp_nocostr_dead"] = { reclaimable = true, blocking = true, unitName = "andhp_nocostr", energy = 0, metal = 3206, }
featureTable["andhp_nocostr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andhvc_dead"] = { reclaimable = true, blocking = true, unitName = "andhvc", energy = 0, metal = 458, }
featureTable["andhvc_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 183, }
featureTable["andill_dead"] = { reclaimable = true, blocking = true, unitName = "andill", energy = 0, metal = 1000, }
featureTable["andill_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 195, }
featureTable["andincubator1_dead"] = { reclaimable = true, blocking = true, unitName = "andincubator1", energy = 0, metal = 3206, }
featureTable["andincubator1_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andincubator2_dead"] = { reclaimable = true, blocking = true, unitName = "andincubator2", energy = 0, metal = 3206, }
featureTable["andincubator2_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andlab_dead"] = { reclaimable = true, blocking = true, unitName = "andlab", energy = 0, metal = 3206, }
featureTable["andlab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andlartic_dead"] = { reclaimable = true, blocking = true, unitName = "andlartic", energy = 0, metal = 55, }
featureTable["andlartic_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 22, }
featureTable["andlipo_dead"] = { reclaimable = true, blocking = true, unitName = "andlipo", energy = 0, metal = 77, }
featureTable["andlipo_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["andmex_dead"] = { reclaimable = true, blocking = true, unitName = "andmexun", energy = 0, metal = 128, }
featureTable["andmex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 51, }
featureTable["andmexun_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 128, }
featureTable["andmexun_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 51, }
featureTable["andmisa_dead"] = { reclaimable = true, blocking = true, unitName = "andmisa", energy = 0, metal = 123, }
featureTable["andmisa_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 49, }
featureTable["andmstor_dead"] = { reclaimable = true, blocking = true, unitName = "andmstor", energy = 0, metal = 198, }
featureTable["andmstor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 79, }
featureTable["andnikola_dead"] = { reclaimable = true, blocking = true, unitName = "andnikola", energy = 0, metal = 200, }
featureTable["andnikola_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 80, }
featureTable["andogre_andogre_dead"] = { reclaimable = true, blocking = true, unitName = "andogre", energy = 0, metal = 623, }
featureTable["andogre_andogre_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 327, }
featureTable["andplat_dead"] = { reclaimable = true, blocking = true, unitName = "andplat", energy = 0, metal = 553, }
featureTable["andpopaa_andpopaa_dead"] = { reclaimable = true, blocking = true, unitName = "andpopaa", energy = 0, metal = 0, }
featureTable["andrad_dead"] = { reclaimable = true, blocking = true, unitName = "andrad", energy = 0, metal = 35, }
featureTable["andrad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["androck_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 200, }
featureTable["androck_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 80, }
featureTable["andscouter_dead"] = { reclaimable = true, blocking = true, unitName = "andscouter", energy = 0, metal = 244, }
featureTable["andscouter_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 98, }
featureTable["andshield_dead"] = { reclaimable = true, blocking = true, unitName = "andshield", energy = 0, metal = 2296, }
featureTable["andshield_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 918, }
featureTable["andsolar_dead"] = { reclaimable = true, blocking = true, unitName = "andsolar", energy = 0, metal = 72, }
featureTable["andsolar_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 29, }
featureTable["andtanko_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 200, }
featureTable["andtanko_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 80, }
featureTable["andtesla_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 200, }
featureTable["andtesla_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 80, }
featureTable["andtorreattacco_anim1_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 3206, }
featureTable["andtorreattacco_anim1_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andtorreattacco_anim2_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 3206, }
featureTable["andtorreattacco_anim2_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andtorreattacco_dead"] = { reclaimable = true, blocking = true, unitName = "andtorreattacco", energy = 0, metal = 3206, }
featureTable["andtorreattacco_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["andwall_dead"] = { reclaimable = true, blocking = true, unitName = "andwall", energy = 0, metal = 77, }
featureTable["andwall_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["andwind_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 23, }
featureTable["andwind_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 9, }
featureTable["antenna_single_feature"] = { reclaimable = true, blocking = true, energy = 500, metal = 1000, }
featureTable["arm_defender_dead"] = { reclaimable = true, blocking = true, unitName = "arm_defender", energy = 0, metal = 63, }
featureTable["armaak_dead"] = { reclaimable = true, blocking = true, unitName = "armaak", energy = 0, metal = 314, }
featureTable["armaak_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 126, }
featureTable["armaap_dead"] = { reclaimable = true, blocking = true, unitName = "armaap", energy = 0, metal = 1953, }
featureTable["armaap_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 977, }
featureTable["armaas_dead"] = { reclaimable = true, blocking = false, unitName = "armaas", energy = 0, metal = 325, }
featureTable["armaas_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 164, }
featureTable["armaca_1_dead"] = { reclaimable = true, blocking = true, unitName = "armaca", energy = 0, metal = 2176, }
featureTable["armack_dead"] = { reclaimable = true, blocking = true, unitName = "armack", energy = 0, metal = 189, }
featureTable["armack_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 76, }
featureTable["armacsub_dead"] = { reclaimable = true, blocking = false, unitName = "armacsub", energy = 0, metal = 452, }
featureTable["armacsub_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 207, }
featureTable["armacv_dead"] = { reclaimable = true, blocking = true, unitName = "armacv", energy = 0, metal = 280, }
featureTable["armacv_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 112, }
featureTable["armalab_dead"] = { reclaimable = true, blocking = true, unitName = "armalab", energy = 0, metal = 1773, }
featureTable["armalab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 887, }
featureTable["armamb_dead"] = { reclaimable = true, blocking = true, unitName = "armfamb", energy = 0, metal = 1522, }
featureTable["armamb_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 609, }
featureTable["armamd_dead"] = { reclaimable = true, blocking = true, unitName = "armamd", energy = 0, metal = 934, }
featureTable["armamd_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 374, }
featureTable["armamex_dead"] = { reclaimable = true, blocking = true, unitName = "armamex", energy = 0, metal = 103, }
featureTable["armamex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 41, }
featureTable["armanni_dead"] = { reclaimable = true, blocking = true, unitName = "armanni", energy = 0, metal = 1940, }
featureTable["armanni_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 776, }
featureTable["armap_dead"] = { reclaimable = true, blocking = true, unitName = "eufap", energy = 0, metal = 553, }
featureTable["armap_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 221, }
featureTable["armarad_dead"] = { reclaimable = true, blocking = true, unitName = "armarad", energy = 0, metal = 341, }
featureTable["armarad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 136, }
featureTable["armarch_dead"] = { reclaimable = true, blocking = true, unitName = "armarch", energy = 0, metal = 1745, }
featureTable["armarch_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 856, }
featureTable["armasp_dead"] = { reclaimable = true, blocking = true, unitName = "armasp", energy = 0, metal = 377, }
featureTable["armasp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 131, }
featureTable["armasy_dead"] = { reclaimable = true, blocking = false, unitName = "armasy", energy = 0, metal = 2232, }
featureTable["armavp_dead"] = { reclaimable = true, blocking = true, unitName = "armavp", energy = 0, metal = 1754, }
featureTable["armavp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 877, }
featureTable["armbats_dead"] = { reclaimable = true, blocking = false, unitName = "armbats", energy = 0, metal = 3368, }
featureTable["armbats_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1066, }
featureTable["armbrtha_dead"] = { reclaimable = true, blocking = true, unitName = "armbrtha", energy = 0, metal = 2720, }
featureTable["armbrtha_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1088, }
featureTable["armbull_dead"] = { reclaimable = true, blocking = true, unitName = "armbull", energy = 0, metal = 549, }
featureTable["armbull_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 220, }
featureTable["armcamp_dead"] = { reclaimable = true, blocking = true, unitName = "armcamp", energy = 0, metal = 1000, }
featureTable["armcamp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 500, }
featureTable["armcarry_dead"] = { reclaimable = true, blocking = true, unitName = "armcarry", energy = 0, metal = 0, }
featureTable["armcroc_dead"] = { reclaimable = true, blocking = false, unitName = "armcroc", energy = 0, metal = 238, }
featureTable["armcroc_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 119, }
featureTable["armcrus_dead"] = { reclaimable = true, blocking = false, unitName = "armcrus", energy = 0, metal = 1272, }
featureTable["armcrus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 466, }
featureTable["armcs_dead"] = { reclaimable = true, blocking = false, unitName = "armcs", energy = 0, metal = 166, }
featureTable["armcs_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 59, }
featureTable["armcv_dead"] = { reclaimable = true, blocking = true, unitName = "armcv", energy = 0, metal = 83, }
featureTable["armcv_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 33, }
featureTable["armdrag_death"] = { reclaimable = true, blocking = true, unitName = "armdrag", energy = 0, metal = 5, }
featureTable["armdrag_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2, }
featureTable["armeyes_dead"] = { reclaimable = true, blocking = false, unitName = "armeyes", energy = 0, metal = 12, }
featureTable["armfamb_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 1522, }
featureTable["armfamb_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 609, }
featureTable["armfanni_dead"] = { reclaimable = true, blocking = true, unitName = "armfanni", energy = 0, metal = 1940, }
featureTable["armfanni_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 776, }
featureTable["armfarad_dead"] = { reclaimable = true, blocking = true, unitName = "armfarad", energy = 0, metal = 341, }
featureTable["armfarad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 136, }
featureTable["armfast_dead"] = { reclaimable = true, blocking = true, unitName = "armkengu", energy = 0, metal = 105, }
featureTable["armfast_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 42, }
featureTable["armfav_dead"] = { reclaimable = true, blocking = false, unitName = "armfav", energy = 0, metal = 15, }
featureTable["armfav_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 6, }
featureTable["armfboy_dead"] = { reclaimable = true, blocking = true, unitName = "armfboy", energy = 0, metal = 1008, }
featureTable["armfboy_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 403, }
featureTable["armfff_dead"] = { reclaimable = true, blocking = false, energy = 0, metal = 5009, }
featureTable["armfflak_dead"] = { reclaimable = true, blocking = true, unitName = "armfflak", energy = 0, metal = 500, }
featureTable["armfflak_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 200, }
featureTable["armfguard_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 1069, }
featureTable["armfguard_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 428, }
featureTable["armfhllt_dead"] = { reclaimable = true, blocking = true, unitName = "armfhllt", energy = 0, metal = 114, }
featureTable["armfhllt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 46, }
featureTable["armfhlt_dead"] = { reclaimable = true, blocking = true, unitName = "armfhlt", energy = 0, metal = 269, }
featureTable["armfhlt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 108, }
featureTable["armfido_dead"] = { reclaimable = true, blocking = true, unitName = "armfido", energy = 0, metal = 164, }
featureTable["armfido_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 66, }
featureTable["armflak_dead"] = { reclaimable = true, blocking = true, unitName = "armflak", energy = 0, metal = 500, }
featureTable["armflak_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 200, }
featureTable["armflash_dead"] = { reclaimable = true, blocking = true, unitName = "armflash", energy = 0, metal = 71, }
featureTable["armflash_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 28, }
featureTable["armfllt_dead"] = { reclaimable = true, blocking = true, unitName = "armfllt", energy = 0, metal = 53, }
featureTable["armfllt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 21, }
featureTable["armfmercury_dead"] = { reclaimable = true, blocking = true, unitName = "armfmercury", energy = 0, metal = 1022, }
featureTable["armfmercury_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 409, }
featureTable["armfort_death"] = { reclaimable = true, blocking = true, unitName = "armfort", energy = 0, metal = 15, }
featureTable["armfort_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 7, }
featureTable["armfrad_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 35, }
featureTable["armfrad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["armfrl_dead"] = { reclaimable = true, blocking = true, unitName = "armfrl", energy = 0, metal = 51, }
featureTable["armfrl_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 20, }
featureTable["armfus_dead"] = { reclaimable = true, blocking = true, unitName = "armfus", energy = 0, metal = 2603, }
featureTable["armfus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1041, }
featureTable["armgant_dead"] = { reclaimable = true, blocking = true, unitName = "icugant", energy = 0, metal = 5270, }
featureTable["armgant_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2635, }
featureTable["armgate_dead"] = { reclaimable = true, blocking = true, unitName = "armgate", energy = 0, metal = 2296, }
featureTable["armgate_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 918, }
featureTable["armgeo_dead"] = { reclaimable = true, blocking = true, unitName = "armgeo", energy = 0, metal = 338, }
featureTable["armgeo_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 135, }
featureTable["armguard_dead"] = { reclaimable = true, blocking = true, unitName = "armguard", energy = 0, metal = 1069, }
featureTable["armguard_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 428, }
featureTable["armhlt_dead"] = { reclaimable = true, blocking = true, unitName = "armhlt", energy = 0, metal = 269, }
featureTable["armhlt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 108, }
featureTable["armhvytransp_armalab_dead"] = { reclaimable = true, blocking = true, unitName = "armhvytransp", energy = 0, metal = 1773, }
featureTable["armhvytransp_armalab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 887, }
featureTable["armjam_dead"] = { reclaimable = true, blocking = true, unitName = "armjam", energy = 0, metal = 78, }
featureTable["armjam_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 39, }
featureTable["armjamt_dead"] = { reclaimable = true, blocking = true, unitName = "armjamt", energy = 0, metal = 147, }
featureTable["armjanus_dead"] = { reclaimable = true, blocking = true, unitName = "armjanus", energy = 0, metal = 147, }
featureTable["armjanus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 59, }
featureTable["armjeth_dead"] = { reclaimable = true, blocking = true, unitName = "armjeth", energy = 0, metal = 75, }
featureTable["armjeth_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 30, }
featureTable["armlab_dead"] = { reclaimable = true, blocking = true, unitName = "armlab", energy = 0, metal = 458, }
featureTable["armlab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 183, }
featureTable["armlatnk_dead"] = { reclaimable = true, blocking = true, unitName = "armlatnk", energy = 0, metal = 200, }
featureTable["armlatnk_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 80, }
featureTable["armmanni_dead"] = { reclaimable = true, blocking = true, unitName = "armmanni", energy = 0, metal = 734, }
featureTable["armmanni_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 294, }
featureTable["armmark_dead"] = { reclaimable = true, blocking = true, unitName = "armmark", energy = 0, metal = 76, }
featureTable["armmark_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 38, }
featureTable["armmart_dead"] = { reclaimable = true, blocking = true, unitName = "armmart", energy = 0, metal = 198, }
featureTable["armmart_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 79, }
featureTable["armmav_dead"] = { reclaimable = true, blocking = true, unitName = "armmav", energy = 0, metal = 394, }
featureTable["armmav_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 196, }
featureTable["armmcv_dead"] = { reclaimable = true, blocking = true, unitName = "armmcv", energy = 0, metal = 42761, }
featureTable["armmcv_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 21380, }
featureTable["armmerl_dead"] = { reclaimable = true, blocking = true, unitName = "armmerl", energy = 0, metal = 560, }
featureTable["armmerl_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 224, }
featureTable["armmmkr_dead"] = { reclaimable = true, blocking = true, unitName = "armmmkr", energy = 0, metal = 233, }
featureTable["armmmkr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 93, }
featureTable["armmoho_dead"] = { reclaimable = true, blocking = true, unitName = "armmoho", energy = 0, metal = 378, }
featureTable["armmoho_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 151, }
featureTable["armmship_dead"] = { reclaimable = true, blocking = false, unitName = "armmship", energy = 0, metal = 1721, }
featureTable["armmship_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 491, }
featureTable["armmstor_dead"] = { reclaimable = true, blocking = true, unitName = "armmstor", energy = 0, metal = 198, }
featureTable["armmstor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 79, }
featureTable["armpb_dead"] = { reclaimable = true, blocking = true, unitName = "armpb", energy = 0, metal = 350, }
featureTable["armpb_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 140, }
featureTable["armpincer_dead"] = { reclaimable = true, blocking = true, unitName = "armpincer", energy = 0, metal = 122, }
featureTable["armpopaa_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 684, }
featureTable["armpopaa_dead2"] = { reclaimable = true, blocking = true, energy = 0, metal = 342, }
featureTable["armpopaa_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 171, }
featureTable["armpt_dead"] = { reclaimable = true, blocking = false, unitName = "armpt", energy = 0, metal = 65, }
featureTable["armpt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 26, }
featureTable["armrad_dead"] = { reclaimable = true, blocking = true, unitName = "armrad", energy = 0, metal = 35, }
featureTable["armrad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["armraven_dead"] = { reclaimable = true, blocking = true, unitName = "armraven", energy = 0, metal = 2958, }
featureTable["armraven_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1183, }
featureTable["armraz_dead"] = { reclaimable = true, blocking = true, unitName = "armraz", energy = 0, metal = 2325, }
featureTable["armraz_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 930, }
featureTable["armrl_dead"] = { reclaimable = true, blocking = true, unitName = "armrl", energy = 0, metal = 51, }
featureTable["armrl_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 20, }
featureTable["armrock_dead"] = { reclaimable = true, blocking = true, unitName = "armrock", energy = 0, metal = 63, }
featureTable["armrock_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 25, }
featureTable["armroy_dead"] = { reclaimable = true, blocking = false, unitName = "armroy", energy = 0, metal = 558, }
featureTable["armroy_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 234, }
featureTable["armsam_dead"] = { reclaimable = true, blocking = true, unitName = "armsam", energy = 0, metal = 123, }
featureTable["armsam_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 49, }
featureTable["armsd_dead"] = { reclaimable = true, blocking = true, unitName = "armsd", energy = 0, metal = 566, }
featureTable["armsd_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 227, }
featureTable["armseer_dead"] = { reclaimable = true, blocking = true, unitName = "armseer", energy = 0, metal = 80, }
featureTable["armseer_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 48, }
featureTable["armshltx_dead"] = { reclaimable = true, blocking = true, unitName = "armshltx", energy = 0, metal = 4807, }
featureTable["armshltx_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1923, }
featureTable["armshock_dead"] = { reclaimable = true, blocking = true, unitName = "armshock", energy = 0, metal = 2028, }
featureTable["armshock_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 811, }
featureTable["armsilo_dead"] = { reclaimable = true, blocking = true, unitName = "armsilo", energy = 0, metal = 4956, }
featureTable["armsilo_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1982, }
featureTable["armsnipe_dead"] = { reclaimable = true, blocking = true, unitName = "armsnipe", energy = 0, metal = 322, }
featureTable["armsnipe_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 129, }
featureTable["armsolar_dead"] = { reclaimable = true, blocking = true, unitName = "armsolar", energy = 0, metal = 75, }
featureTable["armsolar_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 30, }
featureTable["armsonar_dead"] = { reclaimable = true, blocking = false, unitName = "armsonar", energy = 0, metal = 13, }
featureTable["armsptk_dead"] = { reclaimable = true, blocking = true, unitName = "armsptk", energy = 0, metal = 244, }
featureTable["armsptk_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 98, }
featureTable["armst_dead"] = { reclaimable = true, blocking = true, unitName = "armst", energy = 0, metal = 138, }
featureTable["armst_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 55, }
featureTable["armstump_dead"] = { reclaimable = true, blocking = true, unitName = "armstump", energy = 0, metal = 152, }
featureTable["armstump_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 61, }
featureTable["armsub_dead"] = { reclaimable = true, blocking = false, unitName = "armsub", energy = 0, metal = 423, }
featureTable["armsub_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 251, }
featureTable["armsubk_dead"] = { reclaimable = true, blocking = false, unitName = "armsubk", energy = 0, metal = 681, }
featureTable["armsubk_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 181, }
featureTable["armsy_dead"] = { reclaimable = true, blocking = false, unitName = "armsy", energy = 0, metal = 400, }
featureTable["armtarg_dead"] = { reclaimable = true, blocking = true, unitName = "armtarg", energy = 0, metal = 492, }
featureTable["armtarg_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 197, }
featureTable["armtigre_dead"] = { reclaimable = true, blocking = true, unitName = "armtigre", energy = 0, metal = 23591, }
featureTable["armtigre_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 11795, }
featureTable["armtl_dead"] = { reclaimable = true, blocking = false, unitName = "armtl", energy = 0, metal = 196, }
featureTable["armuwadves_dead"] = { reclaimable = true, blocking = true, unitName = "armuwadves", energy = 0, metal = 502, }
featureTable["armuwadves_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 201, }
featureTable["armuwadvms_dead"] = { reclaimable = true, blocking = true, unitName = "armuwadvms", energy = 0, metal = 458, }
featureTable["armuwadvms_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 183, }
featureTable["armuwmex_armuwmex_dead"] = { reclaimable = true, blocking = true, unitName = "armuwmex", energy = 0, metal = 36, }
featureTable["armuwmex_armuwmex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["armuwmme_armuwmme_dead"] = { reclaimable = true, blocking = true, unitName = "armuwmme", energy = 0, metal = 391, }
featureTable["armuwmme_armuwmme_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 156, }
featureTable["armveil_dead"] = { reclaimable = true, blocking = true, unitName = "armveil", energy = 0, metal = 77, }
featureTable["armveil_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["armvp_dead"] = { reclaimable = true, blocking = true, unitName = "armvp", energy = 0, metal = 483, }
featureTable["armvp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 193, }
featureTable["armvulc_dead"] = { reclaimable = true, blocking = true, unitName = "armvulc", energy = 0, metal = 22029, }
featureTable["armvulc_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 8812, }
featureTable["armwar_dead"] = { reclaimable = true, blocking = true, unitName = "armwar", energy = 0, metal = 161, }
featureTable["armwar_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 64, }
featureTable["armyork_dead"] = { reclaimable = true, blocking = true, unitName = "armyork", energy = 0, metal = 276, }
featureTable["armyork_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 110, }
featureTable["armzeus_dead"] = { reclaimable = true, blocking = true, unitName = "armzeus", energy = 0, metal = 214, }
featureTable["armzeus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 86, }
featureTable["artefatto_sporco_dead"] = { reclaimable = true, blocking = true, unitName = "artefatto_sporco", energy = 0, metal = 83, }
featureTable["artefatto_sporco_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 33, }
featureTable["aseadragon_dead"] = { reclaimable = true, blocking = false, unitName = "aseadragon", energy = 0, metal = 20879, }
featureTable["aseadragon_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 5066, }
featureTable["blab_dead"] = { reclaimable = true, blocking = true, unitName = "blab", energy = 0, metal = 13845, }
featureTable["blab_flat"] = { reclaimable = true, blocking = true, energy = 0, metal = 9845, }
featureTable["blab_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 11745, }
featureTable["cafus_dead"] = { reclaimable = true, blocking = true, unitName = "cafus", energy = 0, metal = 6440, }
featureTable["cafus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2576, }
featureTable["cgausstw_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 556, }
featureTable["cgausstw_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 443, }
featureTable["chaosmachine_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 328, }
featureTable["chaosmachine_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 181, }
featureTable["chemist_dead"] = { reclaimable = true, blocking = true, unitName = "chemist", energy = 0, metal = 1145, }
featureTable["chemist_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 458, }
featureTable["conartist_dead"] = { reclaimable = true, blocking = true, unitName = "conartist", energy = 0, metal = 124584, }
featureTable["coraak_dead"] = { reclaimable = true, blocking = true, unitName = "coraak", energy = 0, metal = 395, }
featureTable["coraak_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 158, }
featureTable["coraap_dead"] = { reclaimable = true, blocking = true, unitName = "coraap", energy = 0, metal = 1936, }
featureTable["coraap_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 968, }
featureTable["coracd_dead"] = { reclaimable = true, blocking = true, unitName = "coracd", energy = 0, metal = 420, }
featureTable["coracd_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 210, }
featureTable["corack_dead"] = { reclaimable = true, blocking = true, unitName = "corack", energy = 0, metal = 207, }
featureTable["corack_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 83, }
featureTable["coracsub_dead"] = { reclaimable = true, blocking = false, unitName = "coracsub", energy = 0, metal = 449, }
featureTable["coracsub_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 183, }
featureTable["coracv_dead"] = { reclaimable = true, blocking = true, unitName = "coracv", energy = 0, metal = 294, }
featureTable["coracv_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 118, }
featureTable["coradvsol_dead"] = { reclaimable = true, blocking = true, unitName = "coradvsol", energy = 0, metal = 231, }
featureTable["coradvsol_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 92, }
featureTable["corak_dead"] = { reclaimable = true, blocking = false, unitName = "corak", energy = 0, metal = 29, }
featureTable["corak_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 12, }
featureTable["coralab_dead"] = { reclaimable = true, blocking = true, unitName = "coralab", energy = 0, metal = 1743, }
featureTable["coralab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 872, }
featureTable["corangel_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 1852, }
featureTable["corangel_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 954, }
featureTable["corap_dead"] = { reclaimable = true, blocking = true, unitName = "corap", energy = 0, metal = 540, }
featureTable["corap_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 216, }
featureTable["corarad_dead"] = { reclaimable = true, blocking = true, unitName = "corfarad", energy = 0, metal = 339, }
featureTable["corarad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 136, }
featureTable["corarch_dead"] = { reclaimable = true, blocking = false, unitName = "corarch", energy = 0, metal = 354, }
featureTable["corarch_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 125, }
featureTable["corasp_dead"] = { reclaimable = true, blocking = true, unitName = "corasp", energy = 0, metal = 377, }
featureTable["corasp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 131, }
featureTable["corasy_dead"] = { reclaimable = true, blocking = false, unitName = "corasy", energy = 0, metal = 2174, }
featureTable["coravp_dead"] = { reclaimable = true, blocking = true, unitName = "coravp", energy = 0, metal = 1721, }
featureTable["coravp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 860, }
featureTable["corbats_dead"] = { reclaimable = true, blocking = false, unitName = "corbats", energy = 0, metal = 3513, }
featureTable["corbats_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1066, }
featureTable["corbhmth_dead"] = { reclaimable = true, blocking = true, unitName = "corbhmth", energy = 0, metal = 1917, }
featureTable["corbhmth_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 767, }
featureTable["corblackhy_dead"] = { reclaimable = true, blocking = false, unitName = "corblackhy", energy = 0, metal = 22480, }
featureTable["corblackhy_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 10066, }
featureTable["corbrskr_dead"] = { reclaimable = true, blocking = true, unitName = "andbrskr", energy = 0, metal = 128, }
featureTable["corbrskr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 77, }
featureTable["corbuzz_dead"] = { reclaimable = true, blocking = true, unitName = "corbuzz", energy = 0, metal = 21099, }
featureTable["corbuzz_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 8440, }
featureTable["corcan_dead"] = { reclaimable = true, blocking = true, unitName = "corcan", energy = 0, metal = 339, }
featureTable["corcan_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 136, }
featureTable["corcarry_dead"] = { reclaimable = true, blocking = false, unitName = "corcarry", energy = 0, metal = 1026, }
featureTable["corcarry_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 266, }
featureTable["corck_dead"] = { reclaimable = true, blocking = true, unitName = "corck", energy = 0, metal = 73, }
featureTable["corck_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 29, }
featureTable["corcoug_dead"] = { reclaimable = true, blocking = true, unitName = "corcoug", energy = 0, metal = 2325, }
featureTable["corcoug_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 930, }
featureTable["corcrash_dead"] = { reclaimable = true, blocking = true, unitName = "corcrash", energy = 0, metal = 75, }
featureTable["corcrash_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 30, }
featureTable["corcrus_dead"] = { reclaimable = true, blocking = false, unitName = "corcrus", energy = 0, metal = 1241, }
featureTable["corcrus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 476, }
featureTable["corcs_dead"] = { reclaimable = true, blocking = false, unitName = "corcs", energy = 0, metal = 169, }
featureTable["corcs_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 66, }
featureTable["corcv_dead"] = { reclaimable = true, blocking = true, unitName = "corcv", energy = 0, metal = 87, }
featureTable["corcv_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 35, }
featureTable["cordem_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 32391, }
featureTable["cordem_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 16195, }
featureTable["cordoom_dead"] = { reclaimable = true, blocking = true, unitName = "cordoom", energy = 0, metal = 1611, }
featureTable["cordoom_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 644, }
featureTable["cordrag_death"] = { reclaimable = true, blocking = true, unitName = "cordrag", energy = 0, metal = 5, }
featureTable["cordrag_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2, }
featureTable["corestor_dead"] = { reclaimable = true, blocking = true, unitName = "corestor", energy = 0, metal = 108, }
featureTable["corestor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 43, }
featureTable["coresupp_dead"] = { reclaimable = true, blocking = false, unitName = "coresupp", energy = 0, metal = 239, }
featureTable["coreter_dead"] = { reclaimable = true, blocking = true, unitName = "coreter", energy = 0, metal = 65, }
featureTable["coreter_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 26, }
featureTable["corexp_dead"] = { reclaimable = true, blocking = true, unitName = "corexp", energy = 0, metal = 122, }
featureTable["corexp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 49, }
featureTable["coreyes_dead"] = { reclaimable = true, blocking = false, unitName = "coreyes", energy = 0, metal = 12, }
featureTable["corfarad_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 339, }
featureTable["corfarad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 136, }
featureTable["corfav_dead"] = { reclaimable = true, blocking = false, unitName = "corfav", energy = 0, metal = 16, }
featureTable["corfav_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 6, }
featureTable["corfff_dead"] = { reclaimable = true, blocking = false, energy = 0, metal = 17545, }
featureTable["corfflak_dead"] = { reclaimable = true, blocking = true, unitName = "corfflak", energy = 0, metal = 515, }
featureTable["corfflak_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 206, }
featureTable["corfhlt_dead"] = { reclaimable = true, blocking = true, unitName = "corfhlt", energy = 0, metal = 292, }
featureTable["corfhlt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 117, }
featureTable["corflak_dead"] = { reclaimable = true, blocking = true, unitName = "corflak", energy = 0, metal = 515, }
featureTable["corflak_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 206, }
featureTable["corfllt_dead"] = { reclaimable = true, blocking = true, unitName = "corfllt", energy = 0, metal = 55, }
featureTable["corfllt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 22, }
featureTable["corfmd_dead"] = { reclaimable = true, blocking = true, unitName = "corfmd", energy = 0, metal = 980, }
featureTable["corfmd_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 392, }
featureTable["corfort_death"] = { reclaimable = true, blocking = true, unitName = "corfort", energy = 0, metal = 15, }
featureTable["corfort_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 7, }
featureTable["corfpun_dead"] = { reclaimable = true, blocking = true, unitName = "corfpun", energy = 0, metal = 1123, }
featureTable["corfpun_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 449, }
featureTable["corfrad_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 36, }
featureTable["corfrad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["corfrl_dead"] = { reclaimable = true, blocking = true, unitName = "corfrl", energy = 0, metal = 49, }
featureTable["corfrl_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 20, }
featureTable["corftoast_dead"] = { reclaimable = true, blocking = true, unitName = "corftoast", energy = 0, metal = 1507, }
featureTable["corftoast_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 603, }
featureTable["corfus_dead"] = { reclaimable = true, blocking = true, unitName = "corfus", energy = 0, metal = 2927, }
featureTable["corfus_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1171, }
featureTable["corfvipe_dead"] = { reclaimable = true, blocking = true, unitName = "corfvipe", energy = 0, metal = 380, }
featureTable["corfvipe_dead2"] = { reclaimable = true, blocking = true, energy = 0, metal = 152, }
featureTable["corfvipe_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 61, }
featureTable["corgant_dead"] = { reclaimable = true, blocking = true, unitName = "corgant", energy = 0, metal = 5101, }
featureTable["corgant_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["corgarp_dead"] = { reclaimable = true, blocking = true, unitName = "corgarp", energy = 0, metal = 134, }
featureTable["corgate_dead"] = { reclaimable = true, blocking = true, unitName = "corgate", energy = 0, metal = 2428, }
featureTable["corgate_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 971, }
featureTable["corgator_dead"] = { reclaimable = true, blocking = true, unitName = "corgator", energy = 0, metal = 77, }
featureTable["corgator_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["corgeo_dead"] = { reclaimable = true, blocking = true, unitName = "corgeo", energy = 0, metal = 328, }
featureTable["corgeo_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 131, }
featureTable["corgol_dead"] = { reclaimable = true, blocking = true, unitName = "eufbigfoot", energy = 0, metal = 894, }
featureTable["corgol_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 378, }
featureTable["corhlt_dead"] = { reclaimable = true, blocking = true, unitName = "corhlt", energy = 0, metal = 292, }
featureTable["corhlt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 117, }
featureTable["corhors_dead"] = { reclaimable = true, blocking = false, energy = 0, metal = 161, }
featureTable["corhrk_dead"] = { reclaimable = true, blocking = true, unitName = "corhrk", energy = 0, metal = 194, }
featureTable["corhrk_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 78, }
featureTable["corint_dead"] = { reclaimable = true, blocking = true, unitName = "corint", energy = 0, metal = 2813, }
featureTable["corint_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1125, }
featureTable["corjamt_dead"] = { reclaimable = true, blocking = true, unitName = "corjamt", energy = 0, metal = 71, }
featureTable["corkarg_dead"] = { reclaimable = true, blocking = true, unitName = "corkarg", energy = 0, metal = 1014, }
featureTable["corkrog_dead"] = { reclaimable = true, blocking = true, unitName = "corkrog", energy = 0, metal = 17668, }
featureTable["corkrog_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 15067, }
featureTable["corlab_dead"] = { reclaimable = true, blocking = true, unitName = "corlab", energy = 0, metal = 442, }
featureTable["corlab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 177, }
featureTable["corlevlr_dead"] = { reclaimable = true, blocking = true, unitName = "corlevlr", energy = 0, metal = 190, }
featureTable["corlevlr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 76, }
featureTable["corllt_dead"] = { reclaimable = true, blocking = true, unitName = "corllt", energy = 0, metal = 55, }
featureTable["corllt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 22, }
featureTable["cormabm_dead"] = { reclaimable = true, blocking = true, unitName = "cormabm", energy = 0, metal = 980, }
featureTable["cormabm_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 392, }
featureTable["cormart_dead"] = { reclaimable = true, blocking = true, unitName = "cormart", energy = 0, metal = 138, }
featureTable["cormart_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 55, }
featureTable["cormaw_dead"] = { reclaimable = true, blocking = true, unitName = "cormaw", energy = 0, metal = 177, }
featureTable["cormaw_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2, }
featureTable["cormex_dead"] = { reclaimable = true, blocking = true, unitName = "cormex", energy = 0, metal = 33, }
featureTable["cormex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 13, }
featureTable["cormexp_dead"] = { reclaimable = true, blocking = true, unitName = "cormexp", energy = 0, metal = 1442, }
featureTable["cormexp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 577, }
featureTable["cormist_dead"] = { reclaimable = true, blocking = true, unitName = "cormist", energy = 0, metal = 134, }
featureTable["cormist_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 54, }
featureTable["cormmkr_dead"] = { reclaimable = true, blocking = true, unitName = "cormmkr", energy = 0, metal = 228, }
featureTable["cormmkr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 91, }
featureTable["cormoho_dead"] = { reclaimable = true, blocking = true, unitName = "cormoho", energy = 0, metal = 318, }
featureTable["cormoho_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 137, }
featureTable["cormort_dead"] = { reclaimable = true, blocking = true, unitName = "cormort", energy = 0, metal = 118, }
featureTable["cormort_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 47, }
featureTable["cormstor_dead"] = { reclaimable = true, blocking = true, unitName = "cormstor", energy = 0, metal = 208, }
featureTable["cormstor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 83, }
featureTable["corparrow_dead"] = { reclaimable = true, blocking = true, unitName = "corparrow", energy = 0, metal = 642, }
featureTable["corparrow_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 257, }
featureTable["corpt_dead"] = { reclaimable = true, blocking = false, unitName = "corpt", energy = 0, metal = 62, }
featureTable["corpt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 26, }
featureTable["corpun_dead"] = { reclaimable = true, blocking = true, unitName = "corpun", energy = 0, metal = 1123, }
featureTable["corpun_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 449, }
featureTable["corpyro_heap"] = { reclaimable = true, blocking = false, unitName = "corpyro", energy = 0, metal = 124, }
featureTable["corrad_dead"] = { reclaimable = true, blocking = true, unitName = "corrad", energy = 0, metal = 36, }
featureTable["corrad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["corraid_dead"] = { reclaimable = true, blocking = true, unitName = "corraid", energy = 0, metal = 167, }
featureTable["corraid_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 67, }
featureTable["correap_dead"] = { reclaimable = true, blocking = true, unitName = "correap", energy = 0, metal = 350, }
featureTable["correap_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 150, }
featureTable["corrl_dead"] = { reclaimable = true, blocking = true, unitName = "corrl", energy = 0, metal = 49, }
featureTable["corrl_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 20, }
featureTable["corrlnofire_dead"] = { reclaimable = true, blocking = true, unitName = "corrlnofire", energy = 0, metal = 49, }
featureTable["corrlnofire_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 20, }
featureTable["corroy_dead"] = { reclaimable = true, blocking = false, unitName = "corroy", energy = 0, metal = 577, }
featureTable["corroy_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 249, }
featureTable["corsd_dead"] = { reclaimable = true, blocking = true, unitName = "corsd", energy = 0, metal = 584, }
featureTable["corsd_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 234, }
featureTable["corseal_dead"] = { reclaimable = true, blocking = true, unitName = "corseal", energy = 0, metal = 0, }
featureTable["corsent_dead"] = { reclaimable = true, blocking = true, unitName = "corsent", energy = 0, metal = 288, }
featureTable["corsent_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 115, }
featureTable["corshark_dead"] = { reclaimable = true, blocking = false, unitName = "corshark", energy = 0, metal = 321, }
featureTable["corshark_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 127, }
featureTable["corshroud_dead"] = { reclaimable = true, blocking = true, unitName = "corshroud", energy = 0, metal = 81, }
featureTable["corshroud_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 32, }
featureTable["corsilo_dead"] = { reclaimable = true, blocking = true, unitName = "corsilo", energy = 0, metal = 4672, }
featureTable["corsilo_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1869, }
featureTable["corsjam_dead"] = { reclaimable = true, blocking = true, unitName = "corsjam", energy = 0, metal = 0, }
featureTable["corsolar_dead"] = { reclaimable = true, blocking = true, unitName = "corsolar", energy = 0, metal = 72, }
featureTable["corsolar_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 29, }
featureTable["corsonar_dead"] = { reclaimable = true, blocking = false, unitName = "corsonar", energy = 0, metal = 13, }
featureTable["corspec_dead"] = { reclaimable = true, blocking = true, unitName = "corspec", energy = 0, metal = 56, }
featureTable["corspec_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 28, }
featureTable["corspy_dead"] = { reclaimable = true, blocking = false, unitName = "corspy", energy = 0, metal = 29, }
featureTable["corspy_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 12, }
featureTable["corssub_dead"] = { reclaimable = true, blocking = true, unitName = "corssub", energy = 0, metal = 0, }
featureTable["corstorm_dead"] = { reclaimable = true, blocking = true, unitName = "corstorm", energy = 0, metal = 55, }
featureTable["corstorm_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 22, }
featureTable["corsub_dead"] = { reclaimable = true, blocking = false, unitName = "corsub", energy = 0, metal = 353, }
featureTable["corsub_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 150, }
featureTable["corsumo_dead"] = { reclaimable = true, blocking = true, unitName = "corsumo", energy = 0, metal = 1118, }
featureTable["corsumo_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 447, }
featureTable["corsy_dead"] = { reclaimable = true, blocking = false, unitName = "corsy", energy = 0, metal = 390, }
featureTable["cortarg_dead"] = { reclaimable = true, blocking = true, unitName = "cortarg", energy = 0, metal = 487, }
featureTable["cortarg_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 195, }
featureTable["corthud_dead"] = { reclaimable = true, blocking = true, unitName = "corthud", energy = 0, metal = 96, }
featureTable["corthud_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 38, }
featureTable["cortl_dead"] = { reclaimable = true, blocking = false, unitName = "cortl", energy = 0, metal = 205, }
featureTable["cortoast_dead"] = { reclaimable = true, blocking = true, unitName = "cortoast", energy = 0, metal = 1507, }
featureTable["cortoast_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 603, }
featureTable["coruwadves_dead"] = { reclaimable = true, blocking = true, unitName = "coruwadves", energy = 0, metal = 514, }
featureTable["coruwadves_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 206, }
featureTable["coruwadvms_dead"] = { reclaimable = true, blocking = true, unitName = "coruwadvms", energy = 0, metal = 462, }
featureTable["coruwadvms_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 185, }
featureTable["coruwmex_coruwmex_dead"] = { reclaimable = true, blocking = true, unitName = "coruwmex", energy = 0, metal = 36, }
featureTable["coruwmex_coruwmex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["coruwmme_coruwmme_dead"] = { reclaimable = true, blocking = true, unitName = "coruwmme", energy = 0, metal = 550, }
featureTable["coruwmme_coruwmme_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 220, }
featureTable["corvipe_dead"] = { reclaimable = true, blocking = true, unitName = "corvipe", energy = 0, metal = 380, }
featureTable["corvipe_dead2"] = { reclaimable = true, blocking = true, energy = 0, metal = 152, }
featureTable["corvipe_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 61, }
featureTable["corvoyr_dead"] = { reclaimable = true, blocking = true, unitName = "corvoyr", energy = 0, metal = 60, }
featureTable["corvoyr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 24, }
featureTable["corvp_dead"] = { reclaimable = true, blocking = true, unitName = "corvp", energy = 0, metal = 470, }
featureTable["corvp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 188, }
featureTable["corvrad_dead"] = { reclaimable = true, blocking = true, unitName = "corvrad", energy = 0, metal = 64, }
featureTable["corvrad_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 48, }
featureTable["corvroc_dead"] = { reclaimable = true, blocking = true, unitName = "corvroc", energy = 0, metal = 538, }
featureTable["corvroc_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 215, }
featureTable["corwin_dead"] = { reclaimable = true, blocking = true, unitName = "corwin", energy = 0, metal = 27, }
featureTable["corwin_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 11, }
featureTable["corwolv_dead"] = { reclaimable = true, blocking = true, unitName = "corwolv", energy = 0, metal = 103, }
featureTable["cumulo_1_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 70, }
featureTable["cumulo_2_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 70, }
featureTable["cumulo_3_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 70, }
featureTable["cumulo_4_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 70, }
featureTable["cumulo_5_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 70, }
featureTable["cumulo_6_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 70, }
featureTable["decade_dead"] = { reclaimable = true, blocking = true, unitName = "decade", energy = 0, metal = 0, }
featureTable["ebigb_dead"] = { reclaimable = true, blocking = true, unitName = "ebigb", energy = 0, metal = 124584, }
featureTable["eridlon_antenna_feature"] = { reclaimable = true, blocking = true, energy = 2500, metal = 1000, }
featureTable["eridlon_bridge1_feature"] = { reclaimable = true, blocking = true, energy = 2500, metal = 1000, }
featureTable["eridlon_bridge2_feature"] = { reclaimable = true, blocking = true, energy = 2500, metal = 1000, }
featureTable["eridlon_fence_dx_feature"] = { reclaimable = true, blocking = true, energy = 500, metal = 200, }
featureTable["eridlon_fence_feature"] = { reclaimable = true, blocking = true, energy = 500, metal = 200, }
featureTable["eridlon_gate_feature"] = { reclaimable = true, blocking = true, energy = 2500, metal = 1000, }
featureTable["eridlon_gate_wall_feature"] = { reclaimable = true, blocking = true, energy = 2500, metal = 1000, }
featureTable["eridlon_semaforo_60_features"] = { reclaimable = true, blocking = true, energy = 50, metal = 20, }
featureTable["eridlon_semaforo_dx_features"] = { reclaimable = true, blocking = true, energy = 50, metal = 20, }
featureTable["eridlon_semaforo_features"] = { reclaimable = true, blocking = true, energy = 50, metal = 20, }
featureTable["eridlon_semaforo_sx_features"] = { reclaimable = true, blocking = true, energy = 50, metal = 20, }
featureTable["euf_fence_wall_dead"] = { reclaimable = true, blocking = true, unitName = "euf_fence_wall", energy = 0, metal = 77, }
featureTable["euf_fence_wall_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 31, }
featureTable["euf_radar_dead"] = { reclaimable = true, blocking = true, unitName = "euf_radar", energy = 0, metal = 35, }
featureTable["euf_radar_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["eufadvmetex_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 1025, }
featureTable["eufadvmetex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 350, }
featureTable["eufametex_dead"] = { reclaimable = true, blocking = true, unitName = "eufametex", energy = 0, metal = 33, }
featureTable["eufametex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 13, }
featureTable["eufap_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 553, }
featureTable["eufap_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 221, }
featureTable["eufavp_dead"] = { reclaimable = true, blocking = true, unitName = "eufavp", energy = 0, metal = 1608, }
featureTable["eufavp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2040, }
featureTable["eufbigfoot_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 894, }
featureTable["eufbigfoot_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 378, }
featureTable["eufbomb_dead"] = { reclaimable = true, blocking = true, unitName = "eufbomb", energy = 0, metal = 0, }
featureTable["eufcd_dead"] = { reclaimable = true, blocking = true, unitName = "euftrasparte", energy = 0, metal = 0, }
featureTable["eufcp_dead"] = { reclaimable = true, blocking = true, unitName = "eufcp", energy = 0, metal = 520, }
featureTable["eufcp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 260, }
featureTable["eufestor_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 103, }
featureTable["eufestor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 41, }
featureTable["eufher_dead"] = { reclaimable = true, blocking = true, unitName = "eufher", energy = 0, metal = 178, }
featureTable["eufher_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 220, }
featureTable["eufhq_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 35, }
featureTable["eufhq_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["eufkaat_dead"] = { reclaimable = true, blocking = true, unitName = "eufkaat", energy = 0, metal = 228, }
featureTable["eufkaat_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 114, }
featureTable["euflong_dead"] = { reclaimable = true, blocking = true, unitName = "euflong", energy = 0, metal = 454, }
featureTable["euflong_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 129, }
featureTable["eufloony_dead"] = { reclaimable = true, blocking = true, unitName = "eufloony", energy = 0, metal = 562, }
featureTable["eufloony_heap"] = { reclaimable = true, blocking = true, energy = 0, metal = 562, }
featureTable["eufmedic_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 0, }
featureTable["eufmetex_dead"] = { reclaimable = true, blocking = true, unitName = "eufmetex", energy = 0, metal = 33, }
featureTable["eufmetex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 13, }
featureTable["eufmstor_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 0, }
featureTable["eufopp_dead"] = { reclaimable = true, blocking = true, unitName = "eufopp", energy = 0, metal = 126, }
featureTable["eufopp_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 129, }
featureTable["eufpath_dead"] = { reclaimable = true, blocking = true, unitName = "eufpath", energy = 0, metal = 999, }
featureTable["eufpath_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1998, }
featureTable["eufpathsmall_dead"] = { reclaimable = true, blocking = true, unitName = "eufpathsmall", energy = 0, metal = 999, }
featureTable["eufpathsmall_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1998, }
featureTable["eufpilonax_dead"] = { reclaimable = true, blocking = true, unitName = "eufpilonax", energy = 0, metal = 298, }
featureTable["eufpilonax_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 48, }
featureTable["eufrld_dead"] = { reclaimable = true, blocking = true, unitName = "eufrld", energy = 0, metal = 292, }
featureTable["eufrld_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 220, }
featureTable["eufsab_dead"] = { reclaimable = true, blocking = true, unitName = "eufsab", energy = 0, metal = 114, }
featureTable["eufsab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 129, }
featureTable["eufshat_dead"] = { reclaimable = true, blocking = true, unitName = "eufshat", energy = 0, metal = 229, }
featureTable["eufshat_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 129, }
featureTable["eufsnpr_dead"] = { reclaimable = true, blocking = true, unitName = "eufsnpr", energy = 0, metal = 634, }
featureTable["eufsnpr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 317, }
featureTable["eufsolar_dead"] = { reclaimable = true, blocking = true, unitName = "eufsolar", energy = 0, metal = 75, }
featureTable["eufsolar_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 30, }
featureTable["eufspazioporto_armalab_dead"] = { reclaimable = true, blocking = true, unitName = "eufspazioporto", energy = 0, metal = 1773, }
featureTable["eufspazioporto_armalab_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 887, }
featureTable["eufthorn_dead"] = { reclaimable = true, blocking = true, unitName = "eufthorn", energy = 0, metal = 98, }
featureTable["eufthorn_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 129, }
featureTable["exxec_dead"] = { reclaimable = true, blocking = true, unitName = "exxec", energy = 0, metal = 220, }
featureTable["exxec_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 30, }
featureTable["fabbrica_feature_1"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["fabbrica_feature_3"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["fabbrica_feature_3_bis"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["fabbrica_feature_4"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["fhllt_dead"] = { reclaimable = true, blocking = true, unitName = "fhllt", energy = 0, metal = 120, }
featureTable["fhllt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 48, }
featureTable["fmadsam_dead"] = { reclaimable = true, blocking = true, unitName = "fmadsam", energy = 0, metal = 257, }
featureTable["fmadsam_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 103, }
featureTable["folsom_dam_fogna_e_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["folsom_dam_fogna_n_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["folsom_dam_fogna_o_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["folsom_dam_fogna_s_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["folsomdam_paratia_nord_feature"] = { reclaimable = false, blocking = true, energy = 500, metal = 200, }
featureTable["folsomdam_paratia_sud_feature"] = { reclaimable = false, blocking = true, energy = 500, metal = 200, }
featureTable["fpacko_dead"] = { reclaimable = true, blocking = true, unitName = "fpacko", energy = 0, metal = 275, }
featureTable["fpacko_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 110, }
featureTable["gorg_gorg_dead"] = { reclaimable = true, blocking = true, unitName = "gorg", energy = 0, metal = 13959, }
featureTable["gorg_gorg_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2793, }
featureTable["grayhound_dead"] = { reclaimable = true, blocking = true, unitName = "grayhound", energy = 0, metal = 453, }
featureTable["grayhound_dead2"] = { reclaimable = true, blocking = true, energy = 0, metal = 339, }
featureTable["grayhound_dead3"] = { reclaimable = true, blocking = true, energy = 0, metal = 210, }
featureTable["grayhound_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 103, }
featureTable["heavy_transporter_destroyed_front"] = { reclaimable = true, blocking = true, energy = 60000, metal = 10000, }
featureTable["heavy_transporter_destroyed_rear"] = { reclaimable = true, blocking = true, energy = 30000, metal = 5000, }
featureTable["hllt_dead"] = { reclaimable = true, blocking = true, unitName = "hllt", energy = 0, metal = 120, }
featureTable["hllt_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 48, }
featureTable["icuadvsol_dead"] = { reclaimable = true, blocking = true, unitName = "icuadvsol", energy = 0, metal = 223, }
featureTable["icuadvsol_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 89, }
featureTable["icuck_dead"] = { reclaimable = true, blocking = true, unitName = "icuck", energy = 0, metal = 66, }
featureTable["icuck_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 26, }
featureTable["icucom_dead"] = { reclaimable = true, blocking = true, unitName = "icucom", energy = 0, metal = 2500, }
featureTable["icucom_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["icucom_u1_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 2500, }
featureTable["icucom_u1_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["icucom_u2_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 2500, }
featureTable["icucom_u2_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["icucom_u3_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 2500, }
featureTable["icucom_u3_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["icuestor_dead"] = { reclaimable = true, blocking = true, unitName = "icuestor", energy = 0, metal = 103, }
featureTable["icuestor_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 41, }
featureTable["icufff_dead"] = { reclaimable = true, blocking = true, unitName = "icufff", energy = 0, metal = 1754, }
featureTable["icufff_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 877, }
featureTable["icufurie_dead"] = { reclaimable = true, blocking = true, unitName = "icufurie", energy = 0, metal = 9000, }
featureTable["icufurie_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 4500, }
featureTable["icugant_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 5270, }
featureTable["icugant_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 2635, }
featureTable["icuinv_dead"] = { reclaimable = true, blocking = false, unitName = "icuinv", energy = 0, metal = 29, }
featureTable["icuinv_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 12, }
featureTable["iculighlturr_dead"] = { reclaimable = true, blocking = true, unitName = "iculighlturr", energy = 0, metal = 53, }
featureTable["iculighlturr_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 21, }
featureTable["icumetex_dead"] = { reclaimable = true, blocking = true, unitName = "icumetex", energy = 0, metal = 33, }
featureTable["icumetex_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 13, }
featureTable["icupatroller_dead"] = { reclaimable = true, blocking = false, unitName = "icupatroller", energy = 0, metal = 29, }
featureTable["icupatroller_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 12, }
featureTable["icupcan_dead"] = { reclaimable = true, blocking = true, unitName = "icupcan", energy = 0, metal = 720, }
featureTable["icupcan_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 576, }
featureTable["icuwind_dead"] = { reclaimable = true, blocking = true, unitName = "icuwind", energy = 0, metal = 23, }
featureTable["icuwind_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 9, }
featureTable["interceptor_dead"] = { reclaimable = true, blocking = true, energy = 374, metal = 243, }
featureTable["interceptor_heap"] = { reclaimable = true, blocking = false, energy = 132, metal = 157, }
featureTable["juju_dead"] = { reclaimable = true, blocking = true, unitName = "juju", energy = 0, metal = 289, }
featureTable["juju_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 143, }
featureTable["kicucom_dead"] = { reclaimable = true, blocking = true, unitName = "kicucom", energy = 0, metal = 2500, }
featureTable["kicucom_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["knfacom_dead"] = { reclaimable = true, blocking = true, unitName = "knfacom", energy = 0, metal = 2500, }
featureTable["knfacom_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["lab2_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 5270, }
featureTable["lampione_feature_dx"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["lampione_feature_nord"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["lampione_feature_sud"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["lampione_feature_sx"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["madsam_dead"] = { reclaimable = true, blocking = true, unitName = "madsam", energy = 0, metal = 257, }
featureTable["madsam_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 103, }
featureTable["medusa_medusa_dead"] = { reclaimable = true, blocking = true, unitName = "medusa", energy = 0, metal = 1630, }
featureTable["medusa_medusa_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 847, }
featureTable["mercury_dead"] = { reclaimable = true, blocking = true, unitName = "mercury", energy = 0, metal = 1022, }
featureTable["mercury_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 409, }
featureTable["nfaacan_dead"] = { reclaimable = true, blocking = true, unitName = "nfaacan", energy = 0, metal = 720, }
featureTable["nfaacan_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 576, }
featureTable["nfacom_dead"] = { reclaimable = true, blocking = true, unitName = "nfacom_u3", energy = 0, metal = 2500, }
featureTable["nfacom_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["nfacom_u1_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 2500, }
featureTable["nfacom_u1_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["nfacom_u2_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 2500, }
featureTable["nfacom_u2_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["nfacom_u3_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 2500, }
featureTable["nfacom_u3_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1250, }
featureTable["nfafff_corfff_dead"] = { reclaimable = true, blocking = false, unitName = "nfafff", energy = 0, metal = 17545, }
featureTable["packo_dead"] = { reclaimable = true, blocking = true, unitName = "packo", energy = 0, metal = 275, }
featureTable["packo_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 110, }
featureTable["pala001_dead"] = { reclaimable = true, blocking = true, unitName = "pala001", energy = 0, metal = 35, }
featureTable["pala001_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["pala001_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["pala001d_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["pala002_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["pala002d_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["pala003_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["pala003d_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["pala004_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["pala004d_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["pala005_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["pala005d_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["pala006_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 250, }
featureTable["palma001_feature"] = { reclaimable = true, blocking = true, unitName = "palma001", energy = 50, metal = 0, }
featureTable["palma002_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["palma003_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["palma004_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["palma005_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["palma006_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinesnow001_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinesnow002_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinesnow003_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinesnow004_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinesnow005_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinespring001_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinespring002_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinespring003_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinespring004_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["pinespring005_feature"] = { reclaimable = true, blocking = true, energy = 50, metal = 0, }
featureTable["rock001_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rock002_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rock003_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rock004_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rock005_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rocklunar001_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rocklunar002_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rocklunar003_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["rocklunar004_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["screamer_dead"] = { reclaimable = true, blocking = true, unitName = "screamer", energy = 0, metal = 1145, }
featureTable["screamer_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 458, }
featureTable["spiderbot_dead"] = { reclaimable = true, blocking = true, unitName = "spiderbot", energy = 0, metal = 592, }
featureTable["spiderbot_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 291, }
featureTable["station_one_antenna_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 6000, }
featureTable["station_one_antenna_feature"] = { reclaimable = true, blocking = true, energy = 60000, metal = 10000, }
featureTable["station_one_antenna_feature_dead"] = { reclaimable = true, blocking = true, energy = 30000, metal = 5000, }
featureTable["station_one_antenna_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["station_one_antenna_small_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 35, }
featureTable["station_one_antenna_small_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["station_one_antenna_small_ne_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_antenna_small_ne_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_antenna_small_no_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_antenna_small_no_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_antenna_small_se_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_antenna_small_se_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_antenna_small_so_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_antenna_small_so_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_bordo"] = { reclaimable = false, blocking = false, energy = 60000, metal = 10000, }
featureTable["station_one_cannon_dead"] = { reclaimable = true, blocking = true, unitName = "station_one_cannon", energy = 0, metal = 257, }
featureTable["station_one_cannon_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 103, }
featureTable["station_one_scudi_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 150, }
featureTable["station_one_scudi_e_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_scudi_e_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_scudi_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["station_one_scudi_n_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_scudi_n_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_scudi_o_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_scudi_o_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_scudi_s_feature"] = { reclaimable = true, blocking = true, energy = 3000, metal = 1500, }
featureTable["station_one_scudi_s_feature_dead"] = { reclaimable = true, blocking = true, energy = 1500, metal = 750, }
featureTable["station_one_tunnel_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 35, }
featureTable["station_one_tunnel_e_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["station_one_tunnel_e_feature_dead"] = { reclaimable = true, blocking = true, energy = 375, metal = 125, }
featureTable["station_one_tunnel_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 14, }
featureTable["station_one_tunnel_n_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["station_one_tunnel_n_feature_dead"] = { reclaimable = true, blocking = true, energy = 375, metal = 125, }
featureTable["station_one_tunnel_o_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["station_one_tunnel_o_feature_dead"] = { reclaimable = true, blocking = true, energy = 375, metal = 125, }
featureTable["station_one_tunnel_s_feature"] = { reclaimable = true, blocking = true, energy = 750, metal = 375, }
featureTable["station_one_tunnel_s_feature_dead"] = { reclaimable = true, blocking = true, energy = 375, metal = 125, }
featureTable["tact_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 194, }
featureTable["tact_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 98, }
featureTable["tawf001_dead"] = { reclaimable = true, blocking = true, unitName = "tawf001", energy = 0, metal = 114, }
featureTable["tawf001_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 46, }
featureTable["tawf013_dead"] = { reclaimable = true, blocking = true, unitName = "tawf013", energy = 0, metal = 92, }
featureTable["tawf013_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 37, }
featureTable["tawf114_dead"] = { reclaimable = true, blocking = true, unitName = "tawf114", energy = 0, metal = 510, }
featureTable["tawf114_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 244, }
featureTable["therock001_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["therock002_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["therock003_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["therock004_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["therock005_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["therock006_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["therock007_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["therock008_feature"] = { reclaimable = true, blocking = true, energy = 0, metal = 100, }
featureTable["tllcom_dead"] = { reclaimable = true, blocking = true, unitName = "tllcom", energy = 0, metal = 2000, }
featureTable["tllcom_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 1000, }
featureTable["treno_locomotiva_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["treno_rotto1_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["treno_rotto2_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["treno_rotto3_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["treno_rotto4_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["treno_vagone_aperto_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["treno_vagone_chiuso_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["treno_vagone_container_feature"] = { reclaimable = false, blocking = true, energy = 0, metal = 25000, }
featureTable["walker_dead"] = { reclaimable = true, blocking = true, energy = 0, metal = 206, }
featureTable["walker_dead2"] = { reclaimable = true, blocking = true, energy = 0, metal = 103, }
featureTable["walker_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 101, }
featureTable["walker_walker_dead"] = { reclaimable = true, blocking = true, unitName = "walker", energy = 0, metal = 206, }
featureTable["walker_walker_dead2"] = { reclaimable = true, blocking = true, energy = 0, metal = 103, }
featureTable["warhammer_dead"] = { reclaimable = true, blocking = true, unitName = "warhammer", energy = 0, metal = 1500, }
featureTable["warhammer_heap"] = { reclaimable = true, blocking = false, energy = 0, metal = 700, }
featureTable["wmrtsbuilder_1_dead"] = { reclaimable = true, blocking = true, unitName = "wmrtsbuilder", energy = 0, metal = 2176, }
featureTable["treetype0"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype1"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype2"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype3"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype4"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype5"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype6"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype7"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype8"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype9"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype10"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype11"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype12"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype13"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype14"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["treetype15"] = { reclaimable = true, blocking = true, energy = 250, metal = 0, }
featureTable["geovent"] = { reclaimable = false, blocking = false, energy = 0, metal = 0, }
