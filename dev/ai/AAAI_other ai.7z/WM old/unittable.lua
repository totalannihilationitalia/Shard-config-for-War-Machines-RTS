

unitTable["aafus"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 9109,energyCost = 64115,buildTime = 157529,xsize = 14,zsize = 10,totalEnergyOut = 3000,jammerRadius = 0,canFly = false,wreckName = "aafus_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["advmoho"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0099999997764826,techLevel = 5,bigExplosion = false,airLosRadius = 2.4609375,losRadius = 6.5625,sonarRadius = 0,metalCost = 2100,energyCost = 27000,buildTime = 39640,xsize = 12,zsize = 12,totalEnergyOut = -200,jammerRadius = 0,canFly = false,wreckName = "advmoho_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["amgeo"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 1520,energyCost = 24852,buildTime = 33152,xsize = 10,zsize = 16,totalEnergyOut = 1250,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andaafus"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 9109,energyCost = 64115,buildTime = 157529,xsize = 14,zsize = 10,totalEnergyOut = 5000,jammerRadius = 0,canFly = false,wreckName = "andaafus_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andach"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.8671875,losRadius = 10.3125,sonarRadius = 0,metalCost = 285,energyCost = 4000,buildTime = 12882,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andch_dead",airRange = 0,groundRange = 200,submergedRange = 0,isWeapon = true,buildOptions = true,canbuild = {"andhp", "andahp", },mtype = "hov",}

unitTable["andacsp"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.15625,losRadius = 13.75,sonarRadius = 0,metalCost = 400,energyCost = 4084,buildTime = 9432,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andcsp_dead",airRange = 0,groundRange = 200,submergedRange = 0,isWeapon = true,buildOptions = true,canbuild = {"andgant", "andhp", "andahp", },mtype = "veh",}

unitTable["andaestor"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 2.25,losRadius = 6,sonarRadius = 0,metalCost = 790,energyCost = 10032,buildTime = 20416,xsize = 10,zsize = 10,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andaestor_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andahp"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.3984375,losRadius = 9.0625,sonarRadius = 0,metalCost = 3607,energyCost = 14000,buildTime = 18492,xsize = 22,zsize = 18,totalEnergyOut = 0,jammerRadius = 60,canFly = false,wreckName = "andahp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["andalab"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.28125,losRadius = 8.75,sonarRadius = 0,metalCost = 723,energyCost = 1772,buildTime = 7151,xsize = 18,zsize = 14,totalEnergyOut = 500,jammerRadius = 0,canFly = false,wreckName = "andalab_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["andametex"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0099999997764826,techLevel = 5,bigExplosion = false,airLosRadius = 2.4609375,losRadius = 6.5625,sonarRadius = 0,metalCost = 2100,energyCost = 27000,buildTime = 39640,xsize = 12,zsize = 12,totalEnergyOut = -50,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andangel"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 4184,energyCost = 60680,buildTime = 85185,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andangel_dead",airRange = 0,groundRange = 6200,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andarad"] = {
radarRadius = 2100,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 7.96875,losRadius = 21.25,sonarRadius = 0,metalCost = 54,energyCost = 600,buildTime = 1137,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andrad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andartic"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 4.453125,losRadius = 11.875,sonarRadius = 0,metalCost = 4285,energyCost = 25025,buildTime = 78071,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andartic_andartic_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andbrskr"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.22265625,losRadius = 8.59375,sonarRadius = 0,metalCost = 244,energyCost = 1972,buildTime = 2918,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corbrskr_dead",airRange = 0,groundRange = 200,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andch"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.57421875,losRadius = 9.53125,sonarRadius = 0,metalCost = 110,energyCost = 1400,buildTime = 3551,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andch_dead",airRange = 0,groundRange = 200,submergedRange = 0,isWeapon = true,buildOptions = true,canbuild = {"andahp", "andhp", "andplat", },mtype = "hov",}

unitTable["andchaos"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 4.453125,losRadius = 11.875,sonarRadius = 0,metalCost = 1584,energyCost = 12968,buildTime = 18575,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "CGAUSSTW_dead",airRange = 1400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andcom"] = {
radarRadius = 1000,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 0,bigExplosion = false,airLosRadius = 5.2734375,losRadius = 14.0625,sonarRadius = 300,metalCost = 2500,energyCost = 25000,buildTime = 75000,xsize = 4,zsize = 4,totalEnergyOut = 25,jammerRadius = 0,canFly = false,wreckName = "andcom_dead",airRange = 300,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = true,canbuild = {"andlab", "andhp", "andplat", },mtype = "amp",}

unitTable["andcsp"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.15625,losRadius = 13.75,sonarRadius = 0,metalCost = 113,energyCost = 1622,buildTime = 3551,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andcsp_dead",airRange = 0,groundRange = 200,submergedRange = 0,isWeapon = true,buildOptions = true,canbuild = {"andalab", "andlab", "andhp", "andplat", },mtype = "veh",}

unitTable["anddauber"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 2.87109375,losRadius = 7.65625,sonarRadius = 0,metalCost = 285,energyCost = 4265,buildTime = 8427,xsize = 4,zsize = 4,totalEnergyOut = -1,jammerRadius = 0,canFly = false,wreckName = "anddauber_coredauber_dead",airRange = 0,groundRange = 435,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["anddfens"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 4.6875,losRadius = 12.5,sonarRadius = 0,metalCost = 2463,energyCost = 11327,buildTime = 16765,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "anddfens_cordfens_dead",airRange = 0,groundRange = 1320,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andernie"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 2.8125,losRadius = 7.5,sonarRadius = 0,metalCost = 7384,energyCost = 84680,buildTime = 89185,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,airRange = 765,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andestor"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 166,energyCost = 1659,buildTime = 4257,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andestor_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andfig"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.2109375,losRadius = 16.5625,sonarRadius = 0,metalCost = 68,energyCost = 2687,buildTime = 3465,xsize = 4,zsize = 4,totalEnergyOut = 0.69999998807907,jammerRadius = 0,canFly = true,airRange = 500,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andfus"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 4004,energyCost = 19846,buildTime = 70014,xsize = 10,zsize = 8,totalEnergyOut = 1000,jammerRadius = 0,canFly = false,wreckName = "andfus_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andgant"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.28125,losRadius = 8.75,sonarRadius = 0,metalCost = 723,energyCost = 1772,buildTime = 7151,xsize = 18,zsize = 14,totalEnergyOut = 500,jammerRadius = 0,canFly = false,wreckName = "andgant_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["andgaso"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 118,energyCost = 1042,buildTime = 2300,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andgaso_dead",airRange = 0,groundRange = 330,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "hov",}

unitTable["andhartic"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 4.453125,losRadius = 11.875,sonarRadius = 0,metalCost = 4285,energyCost = 25025,buildTime = 78071,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andhartic_andhartic_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andhp"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.28125,losRadius = 8.75,sonarRadius = 0,metalCost = 723,energyCost = 1772,buildTime = 7151,xsize = 18,zsize = 14,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andhp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["andill"] = {
radarRadius = 1480,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 5.390625,losRadius = 14.375,sonarRadius = 0,metalCost = 3500,energyCost = 12000,buildTime = 100000,xsize = 6,zsize = 10,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andill_dead",airRange = 0,groundRange = 1480,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andlab"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.28125,losRadius = 8.75,sonarRadius = 0,metalCost = 723,energyCost = 1772,buildTime = 7151,xsize = 18,zsize = 14,totalEnergyOut = 500,jammerRadius = 0,canFly = false,wreckName = "andlab_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["andlartic"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 84,energyCost = 652,buildTime = 2724,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andlartic_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andlaunch"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 5.859375,losRadius = 15.625,sonarRadius = 0,metalCost = 120965,energyCost = 2686524,buildTime = 1774578,xsize = 16,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armgate_dead",airRange = 65000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andlipo"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.80859375,losRadius = 10.15625,sonarRadius = 0,metalCost = 118,energyCost = 1042,buildTime = 1761,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andlipo_dead",airRange = 0,groundRange = 350,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "hov",}

unitTable["andmex"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0017500000540167,techLevel = 3,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 51,energyCost = 514,buildTime = 1874,xsize = 6,zsize = 6,totalEnergyOut = -3,jammerRadius = 0,canFly = false,wreckName = "andmex_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andmexun"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0010000000474975,techLevel = 1,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 51,energyCost = 514,buildTime = 3460,xsize = 6,zsize = 6,totalEnergyOut = -5,jammerRadius = 0,canFly = false,wreckName = "andmex_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andmisa"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 7.265625,losRadius = 19.375,sonarRadius = 0,metalCost = 140,energyCost = 2027,buildTime = 2945,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andmisa_dead",airRange = 0,groundRange = 600,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "hov",}

unitTable["andmstor"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 305,energyCost = 535,buildTime = 2925,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andmstor_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andnikola"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 0,metalCost = 1129,energyCost = 12477,buildTime = 25000,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andnikola_dead",airRange = 0,groundRange = 950,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "hov",}

unitTable["andogre"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.9765625,losRadius = 15.9375,sonarRadius = 120,metalCost = 2020,energyCost = 33562,buildTime = 50975,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andogre_andogre_dead",airRange = 0,groundRange = 650,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andplat"] = {
radarRadius = 500,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.421875,losRadius = 9.125,sonarRadius = 0,metalCost = 850,energyCost = 1370,buildTime = 7240,xsize = 14,zsize = 14,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andplat_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["andpopaa"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 4.21875,losRadius = 11.25,sonarRadius = 0,metalCost = 735,energyCost = 11788,buildTime = 20800,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andpopaa_andpopaa_dead",airRange = 1000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andrad"] = {
radarRadius = 2100,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 7.96875,losRadius = 21.25,sonarRadius = 0,metalCost = 54,energyCost = 600,buildTime = 1137,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andrad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["androck"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 0,metalCost = 1129,energyCost = 12477,buildTime = 25000,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 950,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "hov",}

unitTable["andscouter"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.15625,losRadius = 13.75,sonarRadius = 0,metalCost = 45,energyCost = 897,buildTime = 1420,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andscouter_dead",airRange = 0,groundRange = 230,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andshield"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 3532,energyCost = 62191,buildTime = 54139,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "andshield_dead",airRange = 400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["andsolar"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 141,energyCost = 0,buildTime = 2766,xsize = 10,zsize = 10,totalEnergyOut = 20,jammerRadius = 0,canFly = false,wreckName = "andsolar_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andstr"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.1015625,losRadius = 10.9375,sonarRadius = 0,metalCost = 653,energyCost = 11175,buildTime = 18380,xsize = 6,zsize = 6,totalEnergyOut = -4,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["andtanko"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 0,metalCost = 1129,energyCost = 12477,buildTime = 25000,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armlatnk_dead",airRange = 0,groundRange = 750,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "hov",}

unitTable["andtesla"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 0,metalCost = 1129,energyCost = 12477,buildTime = 25000,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 475,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "hov",}

unitTable["andwind"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 35,energyCost = 162,buildTime = 1603,xsize = 6,zsize = 6,totalEnergyOut = 6.75,jammerRadius = 0,canFly = false,wreckName = "icuwind_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armaak"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.2265625,losRadius = 12.5,sonarRadius = 0,metalCost = 483,energyCost = 5266,buildTime = 6958,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armaak_dead",airRange = 875,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["armaap"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.65625,losRadius = 9.75,sonarRadius = 0,metalCost = 3006,energyCost = 26986,buildTime = 20851,xsize = 16,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armaap_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armaas"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.03125,losRadius = 14.84375,sonarRadius = 0,metalCost = 658,energyCost = 7058,buildTime = 8628,xsize = 6,zsize = 6,totalEnergyOut = 6.75,jammerRadius = 0,canFly = false,wreckName = "armaas_dead",airRange = 840,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["armaca"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.494140625,losRadius = 11.984375,sonarRadius = 0,metalCost = 2901,energyCost = 31029,buildTime = 27763,xsize = 4,zsize = 4,totalEnergyOut = 10,jammerRadius = 0,canFly = true,wreckName = "armaca_1_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"armap", "armaap", "icufff", },mtype = "veh",}

unitTable["armack"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.7933595180511,losRadius = 10.11562538147,sonarRadius = 0,metalCost = 290,energyCost = 4084,buildTime = 9432,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armack_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"armshltx", "armlab", "armalab", },mtype = "veh",}

unitTable["armacsub"] = {
radarRadius = 50,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 1.828125,losRadius = 4.875,sonarRadius = 0,metalCost = 695,energyCost = 7568,buildTime = 16565,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armacsub_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"armsy", "armasy", },mtype = "sub",}

unitTable["armacv"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.3972654342651,losRadius = 9.0593748092651,sonarRadius = 0,metalCost = 431,energyCost = 5263,buildTime = 12397,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armacv_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"icugant", "armvp", "armavp", },mtype = "veh",}

unitTable["armalab"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.3515625,losRadius = 8.9375,sonarRadius = 0,metalCost = 2729,energyCost = 13761,buildTime = 16224,xsize = 24,zsize = 24,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armalab_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armamb"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 5.1796875,losRadius = 13.8125,sonarRadius = 0,metalCost = 2342,energyCost = 16821,buildTime = 27072,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armamb_dead",airRange = 0,groundRange = 1320,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armamd"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 2.35546875,losRadius = 6.28125,sonarRadius = 0,metalCost = 1437,energyCost = 59439,buildTime = 95678,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armamd_dead",airRange = 72000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armamex"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.00089999998454005,techLevel = 3,bigExplosion = false,airLosRadius = 3.3515625,losRadius = 8.9375,sonarRadius = 0,metalCost = 159,energyCost = 2081,buildTime = 2611,xsize = 6,zsize = 6,totalEnergyOut = -5,jammerRadius = 0,canFly = false,wreckName = "armamex_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armanni"] = {
radarRadius = 1500,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.140625,losRadius = 24.375,sonarRadius = 0,metalCost = 2985,energyCost = 62563,buildTime = 52071,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armanni_dead",airRange = 0,groundRange = 1400,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armap"] = {
radarRadius = 500,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.421875,losRadius = 9.125,sonarRadius = 0,metalCost = 850,energyCost = 1370,buildTime = 7240,xsize = 16,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armap_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armarad"] = {
radarRadius = 3500,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.609375,losRadius = 25.625,sonarRadius = 0,metalCost = 525,energyCost = 17830,buildTime = 11800,xsize = 4,zsize = 4,totalEnergyOut = -18,jammerRadius = 0,canFly = false,wreckName = "armarad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armasp"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 4.189453125,losRadius = 11.171875,sonarRadius = 0,metalCost = 403,energyCost = 4311,buildTime = 9315,xsize = 18,zsize = 18,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armasp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armasy"] = {
radarRadius = 50,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.50390625,losRadius = 9.34375,sonarRadius = 0,metalCost = 3432,energyCost = 10096,buildTime = 15972,xsize = 24,zsize = 24,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armasy_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armatlas"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 1.46484375,losRadius = 3.90625,sonarRadius = 0,metalCost = 64,energyCost = 1239,buildTime = 3850,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armavp"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.3210935592651,losRadius = 8.8562498092651,sonarRadius = 0,metalCost = 2698,energyCost = 13440,buildTime = 17940,xsize = 22,zsize = 18,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armavp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armawac"] = {
radarRadius = 2500,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 14.94140625,losRadius = 39.84375,sonarRadius = 1200,metalCost = 176,energyCost = 8599,buildTime = 12819,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armbats"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 5181,energyCost = 20731,buildTime = 58730,xsize = 14,zsize = 14,totalEnergyOut = 52,jammerRadius = 0,canFly = false,wreckName = "armbats_dead",airRange = 0,groundRange = 1240,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["armbrawl"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.4453125,losRadius = 17.1875,sonarRadius = 0,metalCost = 300,energyCost = 6000,buildTime = 20000,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 380,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armbrtha"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 4184,energyCost = 60680,buildTime = 85185,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armbrtha_dead",airRange = 0,groundRange = 6200,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armbull"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 844,energyCost = 14593,buildTime = 17228,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armbull_dead",airRange = 0,groundRange = 460,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armca"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 0,metalCost = 105,energyCost = 4320,buildTime = 8844,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"armaap", "armlab", "armvp", "armap", "armsy", },mtype = "veh",}

unitTable["armcamp"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.6875,losRadius = 12.5,sonarRadius = 0,metalCost = 1700,energyCost = 22000,buildTime = 32000,xsize = 6,zsize = 6,totalEnergyOut = 0.19999998807907,jammerRadius = 0,canFly = false,wreckName = "armcamp_dead",airRange = 0,groundRange = 800,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armcarry"] = {
radarRadius = 2950,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 12.94921875,losRadius = 34.53125,sonarRadius = 760,metalCost = 1572,energyCost = 71257,buildTime = 85394,xsize = 16,zsize = 16,totalEnergyOut = 225,jammerRadius = 0,canFly = false,wreckName = "armcarry_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "shp",}

unitTable["armcroc"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.359375,losRadius = 11.625,sonarRadius = 0,metalCost = 467,energyCost = 11512,buildTime = 13367,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armcroc_dead",airRange = 0,groundRange = 480,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["armcrus"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.703125,losRadius = 17.875,sonarRadius = 375,metalCost = 1719,energyCost = 13608,buildTime = 19789,xsize = 10,zsize = 10,totalEnergyOut = 0.099999904632568,jammerRadius = 0,canFly = false,wreckName = "armcrus_dead",airRange = 500,groundRange = 740,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["armcs"] = {
radarRadius = 50,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.4125001430511,losRadius = 9.1000003814697,sonarRadius = 0,metalCost = 255,energyCost = 2130,buildTime = 5121,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armcs_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"armsy", "armasy", },mtype = "shp",}

unitTable["armcv"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 2.96484375,losRadius = 7.90625,sonarRadius = 0,metalCost = 128,energyCost = 1802,buildTime = 4066,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armcv_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"armavp", "armlab", "armvp", "armap", "armsy", },mtype = "veh",}

unitTable["armcybr"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 2243,energyCost = 43062,buildTime = 76203,xsize = 6,zsize = 6,totalEnergyOut = -40,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 500,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armdfly"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.859375,losRadius = 15.625,sonarRadius = 0,metalCost = 318,energyCost = 6667,buildTime = 16022,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 520,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armdrag"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 0.01171875,losRadius = 0.03125,sonarRadius = 0,metalCost = 10,energyCost = 150,buildTime = 255,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armdrag_death",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armeyes"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 6.5625,losRadius = 17.5,sonarRadius = 0,metalCost = 30,energyCost = 800,buildTime = 1500,xsize = 2,zsize = 2,totalEnergyOut = -3,jammerRadius = 0,canFly = false,wreckName = "armeyes_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armfamb"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 5.1796875,losRadius = 13.8125,sonarRadius = 0,metalCost = 2342,energyCost = 16821,buildTime = 27072,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armamb_dead",airRange = 0,groundRange = 1320,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfanni"] = {
radarRadius = 1500,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.140625,losRadius = 24.375,sonarRadius = 0,metalCost = 2985,energyCost = 62563,buildTime = 52071,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfanni_dead",airRange = 0,groundRange = 1400,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfarad"] = {
radarRadius = 3500,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.609375,losRadius = 25.625,sonarRadius = 0,metalCost = 525,energyCost = 17830,buildTime = 11800,xsize = 4,zsize = 4,totalEnergyOut = -18,jammerRadius = 0,canFly = false,wreckName = "armfarad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armfast"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.11328125,losRadius = 10.96875,sonarRadius = 0,metalCost = 177,energyCost = 4382,buildTime = 3960,xsize = 4,zsize = 4,totalEnergyOut = 0.40000000596046,jammerRadius = 0,canFly = false,wreckName = "armfast_dead",airRange = 0,groundRange = 220,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfav"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.85546875,losRadius = 18.28125,sonarRadius = 0,metalCost = 29,energyCost = 342,buildTime = 912,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfav_dead",airRange = 0,groundRange = 180,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfboy"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.9765625,losRadius = 15.9375,sonarRadius = 0,metalCost = 1418,energyCost = 11193,buildTime = 22397,xsize = 4,zsize = 4,totalEnergyOut = -5,jammerRadius = 0,canFly = false,wreckName = "armfboy_dead",airRange = 0,groundRange = 800,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfflak"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 7.8125,losRadius = 16.40625,sonarRadius = 0,metalCost = 769,energyCost = 12198,buildTime = 19005,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfflak_dead",airRange = 775,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfguard"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 1645,energyCost = 11687,buildTime = 21377,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armguard_dead",airRange = 0,groundRange = 1220,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfhllt"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.56640625,losRadius = 14.84375,sonarRadius = 0,metalCost = 176,energyCost = 1434,buildTime = 5324,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfhllt_dead",airRange = 0,groundRange = 475,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfhlt"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 414,energyCost = 4398,buildTime = 9575,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfhlt_dead",airRange = 620,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfido"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.18359375,losRadius = 11.15625,sonarRadius = 0,metalCost = 253,energyCost = 5849,buildTime = 7693,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfido_dead",airRange = 0,groundRange = 650,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfig"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.2109375,losRadius = 16.5625,sonarRadius = 0,metalCost = 68,energyCost = 2687,buildTime = 3465,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 530,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armflak"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 7.8125,losRadius = 16.40625,sonarRadius = 0,metalCost = 769,energyCost = 12198,buildTime = 19005,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armflak_dead",airRange = 775,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armflash"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.50390625,losRadius = 9.34375,sonarRadius = 0,metalCost = 109,energyCost = 914,buildTime = 1963,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armflash_dead",airRange = 0,groundRange = 180,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfllt"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 81,energyCost = 637,buildTime = 2662,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfllt_dead",airRange = 430,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfmercury"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.375,losRadius = 10.9375,sonarRadius = 0,metalCost = 1572,energyCost = 32802,buildTime = 27190,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfmercury_dead",airRange = 2400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfort"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 1.5234375,losRadius = 4.0625,sonarRadius = 0,metalCost = 27,energyCost = 675,buildTime = 965,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfort_death",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armfrad"] = {
radarRadius = 2100,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 7.96875,losRadius = 21.25,sonarRadius = 0,metalCost = 54,energyCost = 600,buildTime = 1137,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armrad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armfrl"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.46875,losRadius = 14.21875,sonarRadius = 0,metalCost = 79,energyCost = 843,buildTime = 1843,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armfrl_dead",airRange = 765,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armfus"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 4004,energyCost = 19846,buildTime = 70014,xsize = 10,zsize = 8,totalEnergyOut = 1000,jammerRadius = 0,canFly = false,wreckName = "armfus_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armgate"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 3532,energyCost = 62191,buildTime = 54139,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armgate_dead",airRange = 400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armgeo"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 520,energyCost = 12568,buildTime = 13078,xsize = 8,zsize = 8,totalEnergyOut = 300,jammerRadius = 0,canFly = false,wreckName = "armgeo_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armguard"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 1645,energyCost = 11687,buildTime = 21377,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armguard_dead",airRange = 0,groundRange = 1220,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armhawk"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.25,losRadius = 17.5,sonarRadius = 0,metalCost = 140,energyCost = 10200,buildTime = 11685,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 562,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armhlt"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 414,energyCost = 4398,buildTime = 9575,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armhlt_dead",airRange = 620,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armjamt"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 2.28515625,losRadius = 6.09375,sonarRadius = 0,metalCost = 226,energyCost = 7945,buildTime = 9955,xsize = 4,zsize = 4,totalEnergyOut = -40,jammerRadius = 500,canFly = false,wreckName = "armjamt_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armjanus"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.80859375,losRadius = 10.15625,sonarRadius = 0,metalCost = 226,energyCost = 2361,buildTime = 3545,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armjanus_dead",airRange = 0,groundRange = 380,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armjeth"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.25,losRadius = 11.78125,sonarRadius = 0,metalCost = 115,energyCost = 1097,buildTime = 1831,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armjeth_dead",airRange = 760,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["armkam"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.09375,losRadius = 16.25,sonarRadius = 0,metalCost = 133,energyCost = 2374,buildTime = 5046,xsize = 4,zsize = 4,totalEnergyOut = -0.80000001192093,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 350,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armlab"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.38671875,losRadius = 9.03125,sonarRadius = 0,metalCost = 605,energyCost = 1130,buildTime = 6760,xsize = 18,zsize = 18,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armlab_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armlance"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 340,energyCost = 7030,buildTime = 15000,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 500,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armlatnk"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 0,metalCost = 307,energyCost = 7000,buildTime = 7534,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armlatnk_dead",airRange = 600,groundRange = 320,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armmakr"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 1,energyCost = 1087,buildTime = 2605,xsize = 6,zsize = 6,totalEnergyOut = -60,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armmanni"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.6171875,losRadius = 20.3125,sonarRadius = 0,metalCost = 1129,energyCost = 12477,buildTime = 25706,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armmanni_dead",airRange = 0,groundRange = 950,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armmark"] = {
radarRadius = 2200,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 10.546875,losRadius = 28.125,sonarRadius = 0,metalCost = 95,energyCost = 1152,buildTime = 3800,xsize = 4,zsize = 4,totalEnergyOut = -12,jammerRadius = 0,canFly = false,wreckName = "armmark_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armmart"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.3515625,losRadius = 8.9375,sonarRadius = 0,metalCost = 254,energyCost = 3840,buildTime = 5530,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armmart_dead",airRange = 0,groundRange = 1150,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armmav"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.4453125,losRadius = 17.1875,sonarRadius = 0,metalCost = 655,energyCost = 12180,buildTime = 18384,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armmav_dead",airRange = 0,groundRange = 365,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armmerl"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 2.89453125,losRadius = 7.71875,sonarRadius = 0,metalCost = 862,energyCost = 6146,buildTime = 15592,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armmerl_dead",airRange = 0,groundRange = 1215,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armmmkr"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 358,energyCost = 19350,buildTime = 34980,xsize = 8,zsize = 8,totalEnergyOut = -600,jammerRadius = 0,canFly = false,wreckName = "armmmkr_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armmoho"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0040000001899898,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 582,energyCost = 7214,buildTime = 14938,xsize = 10,zsize = 10,totalEnergyOut = -25,jammerRadius = 0,canFly = false,wreckName = "armmoho_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armmship"] = {
radarRadius = 1400,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.732421875,losRadius = 9.953125,sonarRadius = 0,metalCost = 2648,energyCost = 9804,buildTime = 22317,xsize = 12,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armmship_dead",airRange = 760,groundRange = 1550,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["armmstor"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 305,energyCost = 535,buildTime = 2925,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armmstor_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armpb"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 7.0078125,losRadius = 18.6875,sonarRadius = 0,metalCost = 638,energyCost = 12896,buildTime = 14961,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armpb_dead",airRange = 0,groundRange = 730,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armpeep"] = {
radarRadius = 1140,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 10.13671875,losRadius = 27.03125,sonarRadius = 0,metalCost = 30,energyCost = 1475,buildTime = 2585,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armpincer"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 2.8125,losRadius = 7.5,sonarRadius = 0,metalCost = 187,energyCost = 1921,buildTime = 2613,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armpincer_dead",airRange = 0,groundRange = 305,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["armpnix"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.046875,losRadius = 8.125,sonarRadius = 0,metalCost = 244,energyCost = 11332,buildTime = 31064,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 1280,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armpraet"] = {
radarRadius = 1200,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 11.71875,losRadius = 31.25,sonarRadius = 1200,metalCost = 27182,energyCost = 577039,buildTime = 552145,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,airRange = 1600,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armpt"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 7.6171875,losRadius = 20.3125,sonarRadius = 0,metalCost = 100,energyCost = 985,buildTime = 2062,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armpt_dead",airRange = 0,groundRange = 220,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["armrad"] = {
radarRadius = 2100,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 7.96875,losRadius = 21.25,sonarRadius = 0,metalCost = 54,energyCost = 600,buildTime = 1137,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armrad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armraven"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 8.203125,losRadius = 21.875,sonarRadius = 0,metalCost = 4551,energyCost = 75625,buildTime = 126522,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armraven_dead",airRange = 0,groundRange = 1350,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armraz"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 5.2734375,losRadius = 14.0625,sonarRadius = 0,metalCost = 3577,energyCost = 63286,buildTime = 88566,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armraz_dead",airRange = 0,groundRange = 475,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armrl"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.46875,losRadius = 14.21875,sonarRadius = 0,metalCost = 79,energyCost = 843,buildTime = 1843,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armrl_dead",airRange = 765,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armrock"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.9609375,losRadius = 10.5625,sonarRadius = 0,metalCost = 97,energyCost = 944,buildTime = 1887,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armrock_dead",airRange = 0,groundRange = 475,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armroy"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.7421875,losRadius = 15.3125,sonarRadius = 400,metalCost = 987,energyCost = 5671,buildTime = 13391,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armroy_dead",airRange = 400,groundRange = 700,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["armsam"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 7.265625,losRadius = 19.375,sonarRadius = 0,metalCost = 140,energyCost = 2027,buildTime = 2945,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armsam_dead",airRange = 0,groundRange = 600,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armscab"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.2734375,losRadius = 14.0625,sonarRadius = 0,metalCost = 1437,energyCost = 88000,buildTime = 95678,xsize = 6,zsize = 6,totalEnergyOut = 200,jammerRadius = 0,canFly = false,wreckName = "ARMSCAB_DEAD",airRange = 72000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armsd"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 2.8125,losRadius = 7.5,sonarRadius = 0,metalCost = 661,energyCost = 6739,buildTime = 11877,xsize = 8,zsize = 8,totalEnergyOut = -125,jammerRadius = 0,canFly = false,wreckName = "armsd_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armseer"] = {
radarRadius = 2300,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 10.546875,losRadius = 28.125,sonarRadius = 0,metalCost = 115,energyCost = 1941,buildTime = 6186,xsize = 6,zsize = 6,totalEnergyOut = -12,jammerRadius = 0,canFly = false,wreckName = "armseer_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armshltx"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 7396,energyCost = 54540,buildTime = 61380,xsize = 22,zsize = 22,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armshltx_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armshock"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 7.32421875,losRadius = 19.53125,sonarRadius = 0,metalCost = 3120,energyCost = 54739,buildTime = 101218,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armshock_dead",airRange = 0,groundRange = 1425,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armsilo"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 7625,energyCost = 84268,buildTime = 178453,xsize = 14,zsize = 14,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armsilo_dead",airRange = 72000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armsnipe"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 535,energyCost = 14727,buildTime = 19137,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 10,canFly = false,wreckName = "armsnipe_dead",airRange = 0,groundRange = 900,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armsolar"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 145,energyCost = 0,buildTime = 2845,xsize = 10,zsize = 10,totalEnergyOut = 20,jammerRadius = 0,canFly = false,wreckName = "armsolar_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armsonar"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 6.03515625,losRadius = 16.09375,sonarRadius = 1200,metalCost = 20,energyCost = 403,buildTime = 912,xsize = 4,zsize = 4,totalEnergyOut = -10,jammerRadius = 0,canFly = false,wreckName = "armsonar_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armsptk"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.15625,losRadius = 13.75,sonarRadius = 0,metalCost = 375,energyCost = 4200,buildTime = 8775,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armsptk_dead",airRange = 0,groundRange = 550,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armst"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 212,energyCost = 3480,buildTime = 6704,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armst_dead",airRange = 0,groundRange = 220,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armstump"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.80859375,losRadius = 10.15625,sonarRadius = 0,metalCost = 201,energyCost = 1746,buildTime = 2904,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armstump_dead",airRange = 0,groundRange = 350,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armsub"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.265625,losRadius = 11.375,sonarRadius = 450,metalCost = 651,energyCost = 3724,buildTime = 9894,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armsub_dead",airRange = 500,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "sub",}

unitTable["armsubk"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 525,metalCost = 1048,energyCost = 9481,buildTime = 17767,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armsubk_dead",airRange = 600,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "sub",}

unitTable["armsy"] = {
radarRadius = 50,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.2296876907349,losRadius = 8.6125001907349,sonarRadius = 0,metalCost = 615,energyCost = 775,buildTime = 6050,xsize = 16,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armsy_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armtarg"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 757,energyCost = 6802,buildTime = 8707,xsize = 8,zsize = 8,totalEnergyOut = -150,jammerRadius = 0,canFly = false,wreckName = "armtarg_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armthund"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 2.28515625,losRadius = 6.09375,sonarRadius = 0,metalCost = 145,energyCost = 4075,buildTime = 4778,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 1280,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armtigre"] = {
radarRadius = 230,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 4.6875,losRadius = 12.5,sonarRadius = 230,metalCost = 13000,energyCost = 270000,buildTime = 290000,xsize = 8,zsize = 8,totalEnergyOut = -0.60000002384186,jammerRadius = 0,canFly = false,wreckName = "armtigre_dead",airRange = 0,groundRange = 800,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armtl"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 302,energyCost = 2058,buildTime = 4120,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armtl_dead",airRange = 550,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armuwadves"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 1.98046875,losRadius = 5.28125,sonarRadius = 0,metalCost = 773,energyCost = 10094,buildTime = 20302,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armuwadves_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armuwadvms"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 2.28515625,losRadius = 6.09375,sonarRadius = 0,metalCost = 705,energyCost = 10493,buildTime = 20391,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armuwadvms_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armuwmex"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0.0010000000474975,techLevel = 3,bigExplosion = false,airLosRadius = 2.1328125,losRadius = 5.6875,sonarRadius = 0,metalCost = 55,energyCost = 674,buildTime = 1875,xsize = 6,zsize = 6,totalEnergyOut = -2,jammerRadius = 0,canFly = false,wreckName = "armuwmex_armuwmex_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armuwmme"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0.0040000001899898,techLevel = 5,bigExplosion = false,airLosRadius = 2.1328125,losRadius = 5.6875,sonarRadius = 0,metalCost = 601,energyCost = 9164,buildTime = 35370,xsize = 10,zsize = 10,totalEnergyOut = -25,jammerRadius = 0,canFly = false,wreckName = "armuwmme_armuwmme_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armveil"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 1.81640625,losRadius = 4.84375,sonarRadius = 0,metalCost = 119,energyCost = 17501,buildTime = 9080,xsize = 4,zsize = 4,totalEnergyOut = -125,jammerRadius = 760,canFly = false,wreckName = "armveil_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["armvp"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 743,energyCost = 1853,buildTime = 7192,xsize = 16,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armvp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["armvulc"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 33890,energyCost = 503644,buildTime = 672961,xsize = 16,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armvulc_dead",airRange = 0,groundRange = 5750,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armwar"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.1015625,losRadius = 10.9375,sonarRadius = 0,metalCost = 248,energyCost = 2944,buildTime = 3828,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armwar_dead",airRange = 0,groundRange = 330,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armyork"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.03125,losRadius = 12.1875,sonarRadius = 0,metalCost = 425,energyCost = 8510,buildTime = 9964,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armyork_dead",airRange = 775,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["armzeus"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.884765625,losRadius = 10.359375,sonarRadius = 0,metalCost = 329,energyCost = 5668,buildTime = 7252,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armzeus_dead",airRange = 0,groundRange = 280,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["aseadragon"] = {
radarRadius = 1530,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = true,airLosRadius = 8.07421875,losRadius = 21.53125,sonarRadius = 0,metalCost = 32122,energyCost = 238406,buildTime = 299523,xsize = 16,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "aseadragon_dead",airRange = 775,groundRange = 2450,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["bigb"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 5.859375,losRadius = 15.625,sonarRadius = 0,metalCost = 687,energyCost = 3608,buildTime = 9993,xsize = 16,zsize = 14,totalEnergyOut = -10,jammerRadius = 0,canFly = false,wreckName = "ebigb_dead",airRange = 598,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["blade"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.3125,losRadius = 19.5,sonarRadius = 0,metalCost = 951,energyCost = 17403,buildTime = 30964,xsize = 4,zsize = 4,totalEnergyOut = -0.099999964237213,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 420,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["bladew"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.265625,losRadius = 11.375,sonarRadius = 0,metalCost = 58,energyCost = 1280,buildTime = 2073,xsize = 4,zsize = 4,totalEnergyOut = 2,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 350,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cafus"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 9107,energyCost = 44730,buildTime = 158390,xsize = 12,zsize = 12,totalEnergyOut = 3000,jammerRadius = 0,canFly = false,wreckName = "cafus_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["chemist"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.375,losRadius = 10.9375,sonarRadius = 0,metalCost = 1762,energyCost = 40362,buildTime = 26280,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "chemist_dead",airRange = 2400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cirr"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 9.375,losRadius = 25,sonarRadius = 0,metalCost = 1961,energyCost = 19946,buildTime = 43453,xsize = 6,zsize = 6,totalEnergyOut = -1,jammerRadius = 0,canFly = true,airRange = 900,groundRange = 650,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cmgeo"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 1420,energyCost = 24568,buildTime = 32078,xsize = 14,zsize = 10,totalEnergyOut = 1250,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["conartist"] = {
radarRadius = 2000,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 8.203125,losRadius = 21.875,sonarRadius = 600,metalCost = 9290,energyCost = 23990,buildTime = 3312,xsize = 8,zsize = 8,totalEnergyOut = 1200,jammerRadius = 0,canFly = false,wreckName = "conartist_dead",airRange = 1110,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["coraak"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.2265625,losRadius = 12.1875,sonarRadius = 0,metalCost = 608,energyCost = 5814,buildTime = 7581,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coraak_dead",airRange = 850,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["coraap"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.580078125,losRadius = 9.546875,sonarRadius = 0,metalCost = 2979,energyCost = 26571,buildTime = 20678,xsize = 16,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coraap_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["coraca"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.494140625,losRadius = 11.984375,sonarRadius = 0,metalCost = 231,energyCost = 8824,buildTime = 18001,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"corap", "coraap", "nfafff", },mtype = "veh",}

unitTable["corack"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.732421875,losRadius = 9.953125,sonarRadius = 0,metalCost = 319,energyCost = 4342,buildTime = 9709,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corack_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"corgant", "corlab", "coralab", },mtype = "veh",}

unitTable["coracsub"] = {
radarRadius = 50,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 1.828125,losRadius = 4.875,sonarRadius = 0,metalCost = 690,energyCost = 7911,buildTime = 17228,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coracsub_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"corsy", "corasy", },mtype = "sub",}

unitTable["coracv"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.4582033157349,losRadius = 9.2218751907349,sonarRadius = 0,metalCost = 452,energyCost = 5512,buildTime = 12882,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coracv_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"corvp", "coravp", },mtype = "veh",}

unitTable["coradvsol"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.046875,losRadius = 8.125,sonarRadius = 0,metalCost = 348,energyCost = 3703,buildTime = 8143,xsize = 8,zsize = 8,totalEnergyOut = 75,jammerRadius = 0,canFly = false,wreckName = "coradvsol_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corak"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.859375,losRadius = 15.625,sonarRadius = 0,metalCost = 34,energyCost = 826,buildTime = 1279,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corak_dead",airRange = 0,groundRange = 240,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["coralab"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.3820314407349,losRadius = 9.0187501907349,sonarRadius = 0,metalCost = 2681,energyCost = 15232,buildTime = 16819,xsize = 14,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coralab_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["corap"] = {
radarRadius = 510,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 830,energyCost = 1340,buildTime = 7180,xsize = 16,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corap_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["corape"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.4453125,losRadius = 17.1875,sonarRadius = 0,metalCost = 320,energyCost = 5800,buildTime = 20000,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 410,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corarad"] = {
radarRadius = 3500,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.140625,losRadius = 24.375,sonarRadius = 0,metalCost = 522,energyCost = 17920,buildTime = 11960,xsize = 4,zsize = 4,totalEnergyOut = -17,jammerRadius = 0,canFly = false,wreckName = "corarad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corarch"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.03125,losRadius = 14.53125,sonarRadius = 0,metalCost = 614,energyCost = 7921,buildTime = 9791,xsize = 6,zsize = 6,totalEnergyOut = 6.75,jammerRadius = 0,canFly = false,wreckName = "corarch_dead",airRange = 840,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["corasp"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 4.189453125,losRadius = 11.171875,sonarRadius = 0,metalCost = 403,energyCost = 4311,buildTime = 9315,xsize = 18,zsize = 18,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corasp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corasy"] = {
radarRadius = 50,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.5343751907349,losRadius = 9.4250001907349,sonarRadius = 0,metalCost = 3345,energyCost = 10763,buildTime = 15696,xsize = 24,zsize = 24,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corasy_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["coravp"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.3515625,losRadius = 8.9375,sonarRadius = 0,metalCost = 2647,energyCost = 14784,buildTime = 18492,xsize = 18,zsize = 14,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coravp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["corawac"] = {
radarRadius = 2400,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 14.6484375,losRadius = 39.0625,sonarRadius = 1200,metalCost = 180,energyCost = 8346,buildTime = 13264,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corbats"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 5404,energyCost = 21941,buildTime = 60640,xsize = 14,zsize = 14,totalEnergyOut = 2,jammerRadius = 0,canFly = false,wreckName = "corbats_dead",airRange = 0,groundRange = 1320,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["corbhmth"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 7.6171875,losRadius = 20.3125,sonarRadius = 0,metalCost = 2949,energyCost = 32428,buildTime = 59640,xsize = 10,zsize = 10,totalEnergyOut = 450,jammerRadius = 0,canFly = false,wreckName = "corbhmth_dead",airRange = 0,groundRange = 1650,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corblackhy"] = {
radarRadius = 1510,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = true,airLosRadius = 7.6171875,losRadius = 20.3125,sonarRadius = 0,metalCost = 34585,energyCost = 252321,buildTime = 309264,xsize = 16,zsize = 16,totalEnergyOut = -15,jammerRadius = 0,canFly = false,wreckName = "corblackhy_dead",airRange = 950,groundRange = 2450,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["corbuzz"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 32460,energyCost = 481404,buildTime = 680630,xsize = 16,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corbuzz_dead",airRange = 0,groundRange = 6100,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corca"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.11328125,losRadius = 10.96875,sonarRadius = 0,metalCost = 110,energyCost = 4580,buildTime = 9286,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"coraap", "corlab", "corvp", "corap", "corsy", },mtype = "veh",}

unitTable["corcan"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.1015625,losRadius = 10.9375,sonarRadius = 0,metalCost = 522,energyCost = 8722,buildTime = 11734,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corcan_dead",airRange = 0,groundRange = 275,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corcarry"] = {
radarRadius = 2700,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 12.1875,losRadius = 32.5,sonarRadius = 740,metalCost = 1579,energyCost = 74715,buildTime = 85271,xsize = 16,zsize = 16,totalEnergyOut = 225,jammerRadius = 0,canFly = false,wreckName = "corcarry_dead",airRange = 72000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["corck"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.50390625,losRadius = 9.34375,sonarRadius = 0,metalCost = 113,energyCost = 1622,buildTime = 3551,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corck_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"coralab", "corlab", "corvp", "corap", "corsy", },mtype = "veh",}

unitTable["corcoug"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 7.67578125,losRadius = 20.46875,sonarRadius = 0,metalCost = 1730,energyCost = 24535,buildTime = 56042,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corcoug_dead",airRange = 0,groundRange = 950,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corcrash"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.25,losRadius = 11.862500190735,sonarRadius = 0,metalCost = 116,energyCost = 1101,buildTime = 1900,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corcrash_dead",airRange = 760,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["corcrus"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.24609375,losRadius = 16.65625,sonarRadius = 375,metalCost = 1794,energyCost = 13551,buildTime = 19950,xsize = 10,zsize = 10,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corcrus_dead",airRange = 500,groundRange = 785,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["corcrw"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.859375,losRadius = 15.625,sonarRadius = 0,metalCost = 6400,energyCost = 72000,buildTime = 150000,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 575,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corcs"] = {
radarRadius = 50,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.3515625,losRadius = 8.9375,sonarRadius = 0,metalCost = 260,energyCost = 2375,buildTime = 5537,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corcs_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"corsy", "corasy", },mtype = "shp",}

unitTable["corcv"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.046875,losRadius = 8.125,sonarRadius = 0,metalCost = 134,energyCost = 1979,buildTime = 4160,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corcv_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"coravp", "corlab", "corvp", "corap", "corsy", },mtype = "veh",}

unitTable["cordem"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 5.625,losRadius = 15,sonarRadius = 0,metalCost = 10489,energyCost = 156664,buildTime = 350143,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "CORDEM_dead",airRange = 500,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cordoom"] = {
radarRadius = 1200,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.140625,losRadius = 24.375,sonarRadius = 0,metalCost = 2478,energyCost = 22599,buildTime = 55276,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cordoom_dead",airRange = 0,groundRange = 950,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cordrag"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 1.5234375,losRadius = 4.0625,sonarRadius = 0,metalCost = 10,energyCost = 150,buildTime = 255,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cordrag_death",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corestor"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 166,energyCost = 1659,buildTime = 4257,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corestor_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["coresupp"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.02734375,losRadius = 13.40625,sonarRadius = 0,metalCost = 367,energyCost = 1912,buildTime = 6660,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coresupp_dead",airRange = 0,groundRange = 320,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["coreter"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.50390625,losRadius = 9.34375,sonarRadius = 0,metalCost = 100,energyCost = 1757,buildTime = 6404,xsize = 6,zsize = 6,totalEnergyOut = -100,jammerRadius = 450,canFly = false,wreckName = "coreter_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corexp"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.00089999998454005,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 188,energyCost = 2264,buildTime = 3460,xsize = 6,zsize = 6,totalEnergyOut = -5,jammerRadius = 0,canFly = false,wreckName = "corexp_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["coreyes"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 6.328125,losRadius = 16.875,sonarRadius = 0,metalCost = 30,energyCost = 800,buildTime = 1500,xsize = 2,zsize = 2,totalEnergyOut = -5,jammerRadius = 0,canFly = false,wreckName = "coreyes_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corfarad"] = {
radarRadius = 3500,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.140625,losRadius = 24.375,sonarRadius = 0,metalCost = 522,energyCost = 17920,buildTime = 11960,xsize = 4,zsize = 4,totalEnergyOut = -17,jammerRadius = 0,canFly = false,wreckName = "corarad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corfav"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.26953125,losRadius = 16.71875,sonarRadius = 0,metalCost = 24,energyCost = 256,buildTime = 1104,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfav_dead",airRange = 0,groundRange = 180,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfflak"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 7.8125,losRadius = 16.40625,sonarRadius = 0,metalCost = 792,energyCost = 13297,buildTime = 20112,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfflak_dead",airRange = 775,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfhlt"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 449,energyCost = 4443,buildTime = 9622,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfhlt_dead",airRange = 620,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfink"] = {
radarRadius = 1120,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 9.78515625,losRadius = 26.09375,sonarRadius = 0,metalCost = 28,energyCost = 1460,buildTime = 2156,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corflak"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 7.8125,losRadius = 16.40625,sonarRadius = 0,metalCost = 792,energyCost = 13297,buildTime = 20112,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corflak_dead",airRange = 775,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfllt"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 84,energyCost = 652,buildTime = 2724,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfllt_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfmd"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 2.28515625,losRadius = 6.09375,sonarRadius = 0,metalCost = 1508,energyCost = 64321,buildTime = 96450,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfmd_dead",airRange = 72000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfort"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 1.5234375,losRadius = 4.0625,sonarRadius = 0,metalCost = 23,energyCost = 612,buildTime = 810,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfort_death",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corfpun"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 1727,energyCost = 12585,buildTime = 19268,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfpun_dead",airRange = 0,groundRange = 1245,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfrad"] = {
radarRadius = 2100,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 7.96875,losRadius = 21.25,sonarRadius = 0,metalCost = 54,energyCost = 600,buildTime = 1137,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corrad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corfrl"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.46875,losRadius = 14.21875,sonarRadius = 0,metalCost = 76,energyCost = 805,buildTime = 1749,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfrl_dead",airRange = 765,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corftoast"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 4.875,losRadius = 13,sonarRadius = 0,metalCost = 2318,energyCost = 16115,buildTime = 25717,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corftoast_dead",airRange = 0,groundRange = 1335,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corfus"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 4203,energyCost = 25292,buildTime = 75424,xsize = 10,zsize = 10,totalEnergyOut = 1100,jammerRadius = 0,canFly = false,wreckName = "corfus_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corfvipe"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 6.3984375,losRadius = 17.0625,sonarRadius = 0,metalCost = 684,energyCost = 13140,buildTime = 15035,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corfvipe_dead",airRange = 0,groundRange = 730,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corgant"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 7848,energyCost = 58524,buildTime = 67321,xsize = 18,zsize = 18,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corgant_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["corgarp"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 2.7421875,losRadius = 7.3125,sonarRadius = 0,metalCost = 206,energyCost = 2441,buildTime = 3101,xsize = 4,zsize = 4,totalEnergyOut = 0.19999998807907,jammerRadius = 0,canFly = false,wreckName = "corgarp_dead",airRange = 0,groundRange = 305,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["corgate"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 3736,energyCost = 63833,buildTime = 57166,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corgate_dead",airRange = 400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corgator"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 118,energyCost = 1042,buildTime = 1761,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corgator_dead",airRange = 0,groundRange = 230,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corgeo"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 505,energyCost = 12375,buildTime = 12875,xsize = 8,zsize = 8,totalEnergyOut = 300,jammerRadius = 0,canFly = false,wreckName = "corgeo_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corgol"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.80078125,losRadius = 15.46875,sonarRadius = 0,metalCost = 1567,energyCost = 19892,buildTime = 26125,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corgol_dead",airRange = 0,groundRange = 750,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corhlt"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 449,energyCost = 4443,buildTime = 9622,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corhlt_dead",airRange = 620,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corhrk"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.341796875,losRadius = 11.578125,sonarRadius = 0,metalCost = 560,energyCost = 5507,buildTime = 6591,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corhrk_dead",airRange = 0,groundRange = 1210,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corhurc"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 2.58984375,losRadius = 6.90625,sonarRadius = 0,metalCost = 313,energyCost = 14365,buildTime = 28461,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 1280,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corint"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 4328,energyCost = 62520,buildTime = 93237,xsize = 10,zsize = 10,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corint_dead",airRange = 0,groundRange = 6600,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corjamt"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 1.21875,losRadius = 3.25,sonarRadius = 0,metalCost = 109,energyCost = 4791,buildTime = 4577,xsize = 4,zsize = 4,totalEnergyOut = -25,jammerRadius = 360,canFly = false,wreckName = "corjamt_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corkarg"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 3577,energyCost = 63286,buildTime = 88609,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corkarg_dead",airRange = 0,groundRange = 600,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corkrog"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 9.90234375,losRadius = 26.40625,sonarRadius = 0,metalCost = 27182,energyCost = 577039,buildTime = 552145,xsize = 2,zsize = 2,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corkrog_dead",airRange = 0,groundRange = 900,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corlab"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.3667967319489,losRadius = 8.9781246185303,sonarRadius = 0,metalCost = 580,energyCost = 1250,buildTime = 7000,xsize = 12,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corlab_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["corlevlr"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.3515625,losRadius = 8.9375,sonarRadius = 0,metalCost = 210,energyCost = 2387,buildTime = 3009,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corlevlr_dead",airRange = 0,groundRange = 315,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corllt"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 84,energyCost = 652,buildTime = 2724,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corllt_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cormabm"] = {
radarRadius = 50,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.2734375,losRadius = 14.0625,sonarRadius = 0,metalCost = 1508,energyCost = 92321,buildTime = 96450,xsize = 6,zsize = 6,totalEnergyOut = 200,jammerRadius = 0,canFly = false,wreckName = "cormabm_dead",airRange = 0,groundRange = 72000,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cormakr"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 1,energyCost = 1156,buildTime = 2682,xsize = 8,zsize = 6,totalEnergyOut = -60,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["cormart"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.50390625,losRadius = 9.34375,sonarRadius = 0,metalCost = 263,energyCost = 3005,buildTime = 4270,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cormart_dead",airRange = 0,groundRange = 1100,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cormaw"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 4.9453125,losRadius = 13.1875,sonarRadius = 0,metalCost = 273,energyCost = 1412,buildTime = 4419,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 8,canFly = false,wreckName = "cormaw_dead",airRange = 0,groundRange = 410,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cormex"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0010000000474975,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 51,energyCost = 514,buildTime = 1874,xsize = 6,zsize = 6,totalEnergyOut = -3,jammerRadius = 0,canFly = false,wreckName = "cormex_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["cormexp"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0035000001080334,techLevel = 5,bigExplosion = false,airLosRadius = 7.921875,losRadius = 21.125,sonarRadius = 0,metalCost = 2219,energyCost = 12121,buildTime = 32500,xsize = 10,zsize = 10,totalEnergyOut = -12,jammerRadius = 0,canFly = false,wreckName = "cormexp_dead",airRange = 650,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cormist"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 7.265625,losRadius = 19.375,sonarRadius = 0,metalCost = 146,energyCost = 2177,buildTime = 3065,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cormist_dead",airRange = 0,groundRange = 600,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cormmkr"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 351,energyCost = 18928,buildTime = 31253,xsize = 8,zsize = 8,totalEnergyOut = -600,jammerRadius = 0,canFly = false,wreckName = "cormmkr_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["cormoho"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0040000001899898,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 598,energyCost = 7677,buildTime = 14125,xsize = 10,zsize = 10,totalEnergyOut = -25,jammerRadius = 0,canFly = false,wreckName = "cormoho_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["cormort"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.515625,losRadius = 9.375,sonarRadius = 0,metalCost = 382,energyCost = 2065,buildTime = 5139,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cormort_dead",airRange = 0,groundRange = 850,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cormstor"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 320,energyCost = 550,buildTime = 2925,xsize = 10,zsize = 10,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cormstor_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["cornanotc"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 4.453125,losRadius = 11.875,sonarRadius = 0,metalCost = 597,energyCost = 5021,buildTime = 5312,xsize = 6,zsize = 6,totalEnergyOut = -30,jammerRadius = 0,canFly = false,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corparrow"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.51171875,losRadius = 12.03125,sonarRadius = 0,metalCost = 988,energyCost = 26854,buildTime = 22181,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corparrow_dead",airRange = 0,groundRange = 575,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["corpt"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 6.25,losRadius = 18.28125,sonarRadius = 0,metalCost = 95,energyCost = 917,buildTime = 1877,xsize = 6,zsize = 6,totalEnergyOut = 6.75,jammerRadius = 0,canFly = false,wreckName = "corpt_dead",airRange = 0,groundRange = 220,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["corpun"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 1727,energyCost = 12585,buildTime = 19268,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corpun_dead",airRange = 0,groundRange = 1245,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corpyro"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 3.7265625,losRadius = 9.9375,sonarRadius = 0,metalCost = 189,energyCost = 2783,buildTime = 5027,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corpyro_heap",airRange = 0,groundRange = 230,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corrad"] = {
radarRadius = 2100,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 7.96875,losRadius = 21.25,sonarRadius = 0,metalCost = 54,energyCost = 600,buildTime = 1137,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corrad_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corraid"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.80859375,losRadius = 10.15625,sonarRadius = 0,metalCost = 211,energyCost = 2219,buildTime = 3312,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corraid_dead",airRange = 0,groundRange = 350,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["correap"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.4140625,losRadius = 14.4375,sonarRadius = 0,metalCost = 589,energyCost = 11348,buildTime = 13530,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "correap_dead",airRange = 0,groundRange = 410,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corrl"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.46875,losRadius = 14.21875,sonarRadius = 0,metalCost = 76,energyCost = 805,buildTime = 1749,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corrl_dead",airRange = 765,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corroy"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.44921875,losRadius = 14.53125,sonarRadius = 400,metalCost = 1021,energyCost = 5756,buildTime = 13368,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corroy_dead",airRange = 400,groundRange = 710,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["corsd"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 2.63671875,losRadius = 7.03125,sonarRadius = 0,metalCost = 698,energyCost = 6363,buildTime = 11955,xsize = 8,zsize = 8,totalEnergyOut = -125,jammerRadius = 0,canFly = false,wreckName = "corsd_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corseal"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.67578125,losRadius = 12.46875,sonarRadius = 0,metalCost = 450,energyCost = 12013,buildTime = 8762,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corseal_dead",airRange = 0,groundRange = 440,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "amp",}

unitTable["corsent"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 7.03125,losRadius = 10.5625,sonarRadius = 0,metalCost = 443,energyCost = 9487,buildTime = 11986,xsize = 6,zsize = 6,totalEnergyOut = -0.5,jammerRadius = 0,canFly = false,wreckName = "corsent_dead",airRange = 775,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corshad"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 1.98046875,losRadius = 5.28125,sonarRadius = 0,metalCost = 156,energyCost = 5968,buildTime = 5054,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 1280,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corshark"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.5703125,losRadius = 12.1875,sonarRadius = 525,metalCost = 956,energyCost = 9245,buildTime = 15529,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corshark_dead",airRange = 600,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "sub",}

unitTable["corshroud"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 1.81640625,losRadius = 4.84375,sonarRadius = 0,metalCost = 124,energyCost = 18304,buildTime = 9392,xsize = 4,zsize = 4,totalEnergyOut = -125,jammerRadius = 700,canFly = false,wreckName = "corshroud_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corsilo"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 7187,energyCost = 77536,buildTime = 181243,xsize = 14,zsize = 14,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corsilo_dead",airRange = 72000,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corsjam"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.72265625,losRadius = 12.59375,sonarRadius = 0,metalCost = 135,energyCost = 2254,buildTime = 7025,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 900,canFly = false,wreckName = "corsjam_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "shp",}

unitTable["corsolar"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 141,energyCost = 0,buildTime = 2766,xsize = 10,zsize = 10,totalEnergyOut = 20,jammerRadius = 0,canFly = false,wreckName = "corsolar_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corsonar"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.68359375,losRadius = 15.15625,sonarRadius = 1200,metalCost = 20,energyCost = 399,buildTime = 900,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corsonar_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corspy"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.4453125,losRadius = 17.1875,sonarRadius = 0,metalCost = 156,energyCost = 11452,buildTime = 22247,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corspy_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corssub"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.09375,losRadius = 16.25,sonarRadius = 550,metalCost = 1757,energyCost = 11940,buildTime = 23007,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corssub_dead",airRange = 690,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "sub",}

unitTable["corstorm"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.037109375,losRadius = 10.765625,sonarRadius = 0,metalCost = 81,energyCost = 853,buildTime = 1722,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corstorm_dead",airRange = 0,groundRange = 475,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corsub"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.265625,losRadius = 11.375,sonarRadius = 450,metalCost = 679,energyCost = 3902,buildTime = 9729,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corsub_dead",airRange = 500,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "sub",}

unitTable["corsumo"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.9765625,losRadius = 15.9375,sonarRadius = 0,metalCost = 2020,energyCost = 33562,buildTime = 50975,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corsumo_dead",airRange = 0,groundRange = 650,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corsy"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.2449216842651,losRadius = 8.6531248092651,sonarRadius = 0,metalCost = 600,energyCost = 750,buildTime = 6000,xsize = 16,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corsy_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["cortarg"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 749,energyCost = 7058,buildTime = 10898,xsize = 10,zsize = 8,totalEnergyOut = -150,jammerRadius = 0,canFly = false,wreckName = "cortarg_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corthud"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.453125,losRadius = 11.875,sonarRadius = 0,metalCost = 132,energyCost = 1061,buildTime = 1971,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corthud_dead",airRange = 0,groundRange = 380,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cortitan"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 360,energyCost = 7800,buildTime = 22072,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 500,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cortl"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 316,energyCost = 2058,buildTime = 4233,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cortl_dead",airRange = 550,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["cortoast"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 4.875,losRadius = 13,sonarRadius = 0,metalCost = 2318,energyCost = 16115,buildTime = 25717,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "cortoast_dead",airRange = 0,groundRange = 1335,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["coruwadves"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = true,airLosRadius = 2.25,losRadius = 6,sonarRadius = 0,metalCost = 790,energyCost = 10032,buildTime = 20416,xsize = 10,zsize = 10,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coruwadves_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["coruwadvms"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 2.1328125,losRadius = 5.6875,sonarRadius = 0,metalCost = 710,energyCost = 10400,buildTime = 20524,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "coruwadvms_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["coruwmex"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0.0010000000474975,techLevel = 3,bigExplosion = false,airLosRadius = 1.98046875,losRadius = 5.28125,sonarRadius = 0,metalCost = 56,energyCost = 519,buildTime = 1887,xsize = 6,zsize = 6,totalEnergyOut = -2,jammerRadius = 0,canFly = false,wreckName = "coruwmex_coruwmex_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["coruwmme"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0.0040000001899898,techLevel = 5,bigExplosion = false,airLosRadius = 1.98046875,losRadius = 5.28125,sonarRadius = 0,metalCost = 846,energyCost = 10076,buildTime = 34783,xsize = 10,zsize = 10,totalEnergyOut = -25,jammerRadius = 0,canFly = false,wreckName = "coruwmme_coruwmme_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corvalk"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 1.46484375,losRadius = 3.90625,sonarRadius = 0,metalCost = 74,energyCost = 1437,buildTime = 4122,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corvamp"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.25,losRadius = 17.1875,sonarRadius = 0,metalCost = 150,energyCost = 9600,buildTime = 9055,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = true,airRange = 550,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corveng"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.46875,losRadius = 15.625,sonarRadius = 0,metalCost = 90,energyCost = 2025,buildTime = 3333,xsize = 4,zsize = 4,totalEnergyOut = -0.72000002861023,jammerRadius = 0,canFly = true,airRange = 500,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corvipe"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 6.3984375,losRadius = 17.0625,sonarRadius = 0,metalCost = 684,energyCost = 13140,buildTime = 15035,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corvipe_dead",airRange = 0,groundRange = 730,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corvoyr"] = {
radarRadius = 2200,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 10.83984375,losRadius = 28.90625,sonarRadius = 0,metalCost = 93,energyCost = 1283,buildTime = 3945,xsize = 4,zsize = 4,totalEnergyOut = -12,jammerRadius = 0,canFly = false,wreckName = "corvoyr_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corvp"] = {
radarRadius = 50,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.26953125,losRadius = 8.71875,sonarRadius = 0,metalCost = 723,energyCost = 1772,buildTime = 7151,xsize = 14,zsize = 14,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corvp_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["corvroc"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 2.58984375,losRadius = 6.90625,sonarRadius = 0,metalCost = 827,energyCost = 6270,buildTime = 15002,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corvroc_dead",airRange = 0,groundRange = 1240,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["corwin"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 42,energyCost = 163,buildTime = 1687,xsize = 6,zsize = 6,totalEnergyOut = 6.75,jammerRadius = 0,canFly = false,wreckName = "corwin_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["corwolv"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.50390625,losRadius = 9.34375,sonarRadius = 0,metalCost = 159,energyCost = 2219,buildTime = 3254,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "corwolv_dead",airRange = 0,groundRange = 710,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["decade"] = {
radarRadius = 0,isBuilding = false,needsWater = true,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.02734375,losRadius = 13.40625,sonarRadius = 0,metalCost = 378,energyCost = 2055,buildTime = 6525,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "decade_dead",airRange = 0,groundRange = 310,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "shp",}

unitTable["demr"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 12.890625,losRadius = 34.375,sonarRadius = 0,metalCost = 5264,energyCost = 47644,buildTime = 171754,xsize = 10,zsize = 10,totalEnergyOut = -5,jammerRadius = 0,canFly = true,airRange = 900,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["ebigb"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 5.859375,losRadius = 15.625,sonarRadius = 0,metalCost = 135685,energyCost = 1145874,buildTime = 14567,xsize = 2,zsize = 2,totalEnergyOut = 250,jammerRadius = 0,canFly = false,wreckName = "ebigb_dead",airRange = 2337,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["exxec"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 4.1015625,losRadius = 10.9375,sonarRadius = 0,metalCost = 475,energyCost = 5311,buildTime = 8500,xsize = 4,zsize = 4,totalEnergyOut = -0.5,jammerRadius = 0,canFly = false,wreckName = "exxec_dead",airRange = 0,groundRange = 275,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["fhllt"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 185,energyCost = 1467,buildTime = 5448,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "fhllt_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["fmadsam"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 6.640625,losRadius = 11.71875,sonarRadius = 0,metalCost = 295,energyCost = 5750,buildTime = 5237,xsize = 6,zsize = 6,totalEnergyOut = -5,jammerRadius = 0,canFly = false,wreckName = "fmadsam_dead",airRange = 840,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["fpacko"] = {
radarRadius = 0,isBuilding = true,needsWater = true,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 6.640625,losRadius = 11.71875,sonarRadius = 0,metalCost = 338,energyCost = 5357,buildTime = 5810,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "fpacko_dead",airRange = 840,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["gorg"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 6.15234375,losRadius = 16.40625,sonarRadius = 0,metalCost = 18705,energyCost = 481165,buildTime = 629630,xsize = 12,zsize = 12,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "gorg_gorg_dead",airRange = 435,groundRange = 590,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["hllt"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.33203125,losRadius = 14.21875,sonarRadius = 0,metalCost = 185,energyCost = 1467,buildTime = 5448,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "hllt_dead",airRange = 435,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["icuadvsol"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 3.046875,losRadius = 8.125,sonarRadius = 0,metalCost = 343,energyCost = 4725,buildTime = 7945,xsize = 10,zsize = 10,totalEnergyOut = 75,jammerRadius = 0,canFly = false,wreckName = "icuadvsol_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["icuck"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 3.57421875,losRadius = 9.53125,sonarRadius = 0,metalCost = 102,energyCost = 1521,buildTime = 3453,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "icuck_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,canbuild = {"armalab", "armlab", "armvp", "armap", "armsy", },mtype = "veh",}

unitTable["icucom"] = {
radarRadius = 700,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 0,bigExplosion = false,airLosRadius = 5.2734375,losRadius = 14.0625,sonarRadius = 300,metalCost = 2500,energyCost = 25000,buildTime = 75000,xsize = 4,zsize = 4,totalEnergyOut = 25,jammerRadius = 0,canFly = false,wreckName = "icucom_dead",airRange = 300,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = true,canbuild = {"armlab", "armvp", "armap", "armsy", },mtype = "amp",}

unitTable["icuestor"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 159,energyCost = 1592,buildTime = 4119,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "icuestor_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["icufff"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 5.9765625,losRadius = 15.9375,sonarRadius = 0,metalCost = 5284,energyCost = 21941,buildTime = 80132,xsize = 20,zsize = 20,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "icufff_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["icufurie"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 8.203125,losRadius = 21.875,sonarRadius = 0,metalCost = 29489,energyCost = 116664,buildTime = 302193,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "icufurie_dead",airRange = 0,groundRange = 650,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["icugant"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 8000,energyCost = 60000,buildTime = 68000,xsize = 18,zsize = 16,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "armgant_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["icuinv"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.453125,losRadius = 11.875,sonarRadius = 0,metalCost = 121,energyCost = 1231,buildTime = 2210,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "icuinv_dead",airRange = 0,groundRange = 380,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["iculighlturr"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 5.7890625,losRadius = 15.4375,sonarRadius = 0,metalCost = 81,energyCost = 637,buildTime = 2662,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "iculighlturr_dead",airRange = 430,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["icumetex"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0.0010000000474975,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 50,energyCost = 521,buildTime = 1800,xsize = 6,zsize = 6,totalEnergyOut = -3,jammerRadius = 0,canFly = false,wreckName = "icumetex_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["icupatroller"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 5.02734375,losRadius = 13.40625,sonarRadius = 0,metalCost = 45,energyCost = 897,buildTime = 1420,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "icupatroller_dead",airRange = 0,groundRange = 180,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["icuwind"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 1,bigExplosion = false,airLosRadius = 3.19921875,losRadius = 8.53125,sonarRadius = 0,metalCost = 35,energyCost = 162,buildTime = 1603,xsize = 6,zsize = 6,totalEnergyOut = 6.75,jammerRadius = 0,canFly = false,wreckName = "icuwind_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = false,mtype = "veh",}

unitTable["interceptor"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 2.34375,losRadius = 6.25,sonarRadius = 0,metalCost = 800,energyCost = 1400,buildTime = 30000,xsize = 8,zsize = 6,totalEnergyOut = -10,jammerRadius = 500,canFly = false,wreckName = "Interceptor_DEAD",airRange = 430,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["madsam"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 6.640625,losRadius = 11.71875,sonarRadius = 0,metalCost = 295,energyCost = 5750,buildTime = 5237,xsize = 6,zsize = 6,totalEnergyOut = -5,jammerRadius = 0,canFly = false,wreckName = "madsam_dead",airRange = 840,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["medusa"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 4.453125,losRadius = 11.875,sonarRadius = 0,metalCost = 2546,energyCost = 27687,buildTime = 25656,xsize = 12,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "medusa_medusa_dead",airRange = 950,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["mercury"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.375,losRadius = 10.9375,sonarRadius = 0,metalCost = 1572,energyCost = 32802,buildTime = 27190,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "mercury_dead",airRange = 2400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["nfacom"] = {
radarRadius = 700,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 0,bigExplosion = false,airLosRadius = 5.2734375,losRadius = 14.0625,sonarRadius = 300,metalCost = 2500,energyCost = 25000,buildTime = 75000,xsize = 4,zsize = 4,totalEnergyOut = 25,jammerRadius = 0,canFly = false,wreckName = "nfacom_dead",airRange = 300,groundRange = 16,submergedRange = 0,isWeapon = true,buildOptions = true,canbuild = {"corlab", "corvp", "corap", "corsy", },mtype = "amp",}

unitTable["nfafff"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 5.9765625,losRadius = 15.9375,sonarRadius = 0,metalCost = 5345,energyCost = 21520,buildTime = 80210,xsize = 24,zsize = 24,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "nfafff_corfff_dead",airRange = 0,groundRange = 0,submergedRange = 0,isWeapon = false,buildOptions = true,mtype = "veh",}

unitTable["odyc"] = {
radarRadius = 4000,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 9.375,losRadius = 25,sonarRadius = 4000,metalCost = 3443,energyCost = 36083,buildTime = 57045,xsize = 8,zsize = 8,totalEnergyOut = -1,jammerRadius = 0,canFly = true,airRange = 900,groundRange = 600,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["orcl"] = {
radarRadius = 4000,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 9.375,losRadius = 25,sonarRadius = 4000,metalCost = 3511,energyCost = 38023,buildTime = 59993,xsize = 8,zsize = 8,totalEnergyOut = -65,jammerRadius = 0,canFly = true,airRange = 900,groundRange = 655,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["ostr"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 12.890625,losRadius = 34.375,sonarRadius = 0,metalCost = 4999,energyCost = 53598,buildTime = 179033,xsize = 10,zsize = 10,totalEnergyOut = -5,jammerRadius = 0,canFly = true,airRange = 900,groundRange = 900,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["packo"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 6.640625,losRadius = 11.71875,sonarRadius = 0,metalCost = 338,energyCost = 5357,buildTime = 5810,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "packo_dead",airRange = 840,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["screamer"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 5,bigExplosion = false,airLosRadius = 9.375,losRadius = 10.9375,sonarRadius = 0,metalCost = 1762,energyCost = 40362,buildTime = 26280,xsize = 8,zsize = 8,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "screamer_dead",airRange = 2400,groundRange = 0,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["taln"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 9.375,losRadius = 25,sonarRadius = 0,metalCost = 2014,energyCost = 19001,buildTime = 44398,xsize = 6,zsize = 6,totalEnergyOut = -1,jammerRadius = 0,canFly = true,airRange = 900,groundRange = 600,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["tawf001"] = {
radarRadius = 0,isBuilding = true,needsWater = false,extractsMetal = 0,techLevel = 3,bigExplosion = false,airLosRadius = 5.56640625,losRadius = 14.84375,sonarRadius = 0,metalCost = 176,energyCost = 1434,buildTime = 5324,xsize = 4,zsize = 4,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "tawf001_dead",airRange = 0,groundRange = 475,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["tawf013"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 2,bigExplosion = false,airLosRadius = 4.265625,losRadius = 11.375,sonarRadius = 0,metalCost = 142,energyCost = 2016,buildTime = 2998,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "tawf013_dead",airRange = 0,groundRange = 710,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["tawf114"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 6.3984375,losRadius = 17.0625,sonarRadius = 0,metalCost = 939,energyCost = 20701,buildTime = 23129,xsize = 6,zsize = 6,totalEnergyOut = 0,jammerRadius = 0,canFly = false,wreckName = "tawf114_dead",airRange = 0,groundRange = 800,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["walker"] = {
radarRadius = 0,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 4,bigExplosion = false,airLosRadius = 5.859375,losRadius = 15.625,sonarRadius = 0,metalCost = 265,energyCost = 2631,buildTime = 3124,xsize = 4,zsize = 4,totalEnergyOut = -0.5,jammerRadius = 0,canFly = false,wreckName = "walker_walker_dead",airRange = 0,groundRange = 370,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}

unitTable["warhammer"] = {
radarRadius = 900,isBuilding = false,needsWater = false,extractsMetal = 0,techLevel = 6,bigExplosion = false,airLosRadius = 8.203125,losRadius = 21.875,sonarRadius = 0,metalCost = 3700,energyCost = 66000,buildTime = 58000,xsize = 6,zsize = 6,totalEnergyOut = -100,jammerRadius = 0,canFly = false,wreckName = "warhammer_dead",airRange = 0,groundRange = 950,submergedRange = 0,isWeapon = true,buildOptions = false,mtype = "veh",}