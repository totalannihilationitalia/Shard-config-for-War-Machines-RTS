--[[
 Task Queues!
]]--
math.randomseed( os.time() )
math.random(); math.random(); math.random()


taskqueues = {
	--
}
