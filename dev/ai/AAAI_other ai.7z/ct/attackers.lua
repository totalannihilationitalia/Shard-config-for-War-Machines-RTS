--[[
Attackers!
]]--

attackerlist = {
	"bbasicmech",
	"bsnipermech",
	"bamphmech",
	"bantitankmech",
	"bsiegemech",
	"bflyingmech",
	"bmissiletank",
	"bassaulttank",
	"bseigeartillery",
	"bfighter",
	"brocketplane",
	"bbomber",
}
